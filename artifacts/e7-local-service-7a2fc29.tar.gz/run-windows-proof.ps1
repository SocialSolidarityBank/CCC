<# 
  E7-1a/E7-1b Local Single service Windows verification
  
  Exercises:
  - DPAPI record protect/unprotect
  - Encrypted SQLite open with real key material
  - Scheduler tick
  - Endpoint-record file permissions
  - Loopback HTTP server on ephemeral port
  
  Outputs JSON status lines only. Never prints key material, bearer tokens,
  ports with tokens, or raw SIDs.
#>
param(
  [Parameter(Mandatory=$true)]
  [string]$Root
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Write-Stage { param([string]$Name) Write-Host "=== $Name ===" }
function Write-Status { param([hashtable]$Status) Write-Host (ConvertTo-Json $Status -Compress) }

# Validate ASCII root
if ($Root -match '[^\x20-\x7E]') {
  Write-Status @{ stage='validate'; status='FAIL'; reason='non-ascii-root' }
  exit 1
}

$bundleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$tempDir = Join-Path $Root "e7-proof-$(Get-Date -Format 'yyyyMMdd-HHmmss')"

try {
  Write-Stage "setup"
  
  # Create temp directory
  New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
  Write-Status @{ stage='setup'; status='OK'; tempDir=$tempDir }
  
  # Copy source bundle (everything except the proof script itself)
  Write-Stage "copy-source"
  Get-ChildItem -Path $bundleRoot -Exclude 'run-windows-proof.ps1' | ForEach-Object {
    Copy-Item -Path $_.FullName -Destination $tempDir -Recurse
  }
  Write-Status @{ stage='copy-source'; status='OK' }
  
  # Frozen install
  Write-Stage "install"
  Push-Location $tempDir
  try {
    $env:npm_config_ignore_scripts = 'true'
    $installResult = & pnpm install --frozen-lockfile --ignore-scripts 2>&1
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='install'; status='FAIL'; reason='pnpm-install-failed' }
      exit 1
    }
    Write-Status @{ stage='install'; status='OK' }
  } finally {
    Pop-Location
  }
  
  # Build native addon
  Write-Stage "build-native"
  Push-Location (Join-Path $tempDir 'adapters/secrets-dpapi')
  try {
    $buildResult = & node scripts/build-native.mjs 2>&1
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='build-native'; status='FAIL'; reason='native-build-failed' }
      exit 1
    }
    Write-Status @{ stage='build-native'; status='OK' }
  } finally {
    Pop-Location
  }
  
  # Run DPAPI adapter tests
  Write-Stage "dpapi-tests"
  Push-Location (Join-Path $tempDir 'adapters/secrets-dpapi')
  try {
    $testResult = & node --test test/contract.test.ts test/recovery.test.ts 2>&1
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='dpapi-tests'; status='FAIL'; reason='dpapi-tests-failed' }
      exit 1
    }
    Write-Status @{ stage='dpapi-tests'; status='OK' }
  } finally {
    Pop-Location
  }
  
  # Create test data directory
  Write-Stage "prepare-data"
  $dataDir = Join-Path $tempDir 'test-data'
  $secretsDir = Join-Path $dataDir 'secrets'
  New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
  New-Item -ItemType Directory -Path $secretsDir -Force | Out-Null
  
  # Run the local-service proof script
  Write-Stage "local-service-proof"
  Push-Location $tempDir
  try {
    $proofScript = @"
import { createHash, randomBytes } from 'node:crypto';
import { writeFile, readFile, rm, access, constants, stat } from 'node:fs/promises';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

// Import adapters
import { createDpapiSecretStore, protectRecord } from './adapters/secrets-dpapi/src/index.ts';
import { createProtectedRecordRepository } from './adapters/secrets-dpapi/src/record-file.ts';
import { openEncryptedSqlite } from './adapters/db-sqlite/src/index.ts';
import { createFileAudioStore } from './adapters/audio-file/src/index.ts';
import { createNodeScheduler } from './adapters/scheduler-node/src/index.ts';
import { createLocalSingleIdentity } from './apps/local-service/src/identity.ts';

const dataDir = process.argv[2];
if (!dataDir) {
  console.log(JSON.stringify({ stage: 'local-service-proof', status: 'FAIL', reason: 'no-data-dir' }));
  process.exit(1);
}

const secretsDir = join(dataDir, 'secrets');
const dbPath = join(dataDir, 'database.sqlite');
const audioDir = join(dataDir, 'audio');
const endpointPath = join(dataDir, 'endpoint.json');

async function runProof() {
  const results = {};
  
  // 1. DPAPI protect/unprotect real keys
  console.log(JSON.stringify({ stage: 'dpapi-protect', status: 'running' }));
  
  const dbKey = randomBytes(32);
  const fileKey = randomBytes(32);
  const piiKey = randomBytes(32);
  
  const dbRecord = await protectRecord('local-single', 'DB_MASTER_KEY', 1, dbKey);
  const fileRecord = await protectRecord('local-single', 'FILE_ENC_KEY', 1, fileKey);
  const piiRecord = await protectRecord('local-single', 'PII_ENC_KEY', 1, piiKey);
  
  // Verify keys are zeroed after protect
  if (dbKey.some(b => b !== 0) || fileKey.some(b => b !== 0) || piiKey.some(b => b !== 0)) {
    console.log(JSON.stringify({ stage: 'dpapi-protect', status: 'FAIL', reason: 'keys-not-zeroed' }));
    process.exit(1);
  }
  
  results.dpapiProtect = 'OK';
  console.log(JSON.stringify({ stage: 'dpapi-protect', status: 'OK' }));
  
  // 2. Create secret store and retrieve keys
  console.log(JSON.stringify({ stage: 'dpapi-store', status: 'running' }));
  
  const store = createDpapiSecretStore('local-single', [dbRecord, fileRecord, piiRecord]);
  const retrievedDb = await store.getBytesWithVersion('DB_MASTER_KEY');
  const retrievedFile = await store.getBytesWithVersion('FILE_ENC_KEY');
  const retrievedPii = await store.getBytesWithVersion('PII_ENC_KEY');
  
  if (!retrievedDb || !retrievedFile || !retrievedPii) {
    console.log(JSON.stringify({ stage: 'dpapi-store', status: 'FAIL', reason: 'key-retrieval-failed' }));
    process.exit(1);
  }
  
  results.dpapiStore = 'OK';
  console.log(JSON.stringify({ stage: 'dpapi-store', status: 'OK' }));
  
  // 3. Encrypted SQLite open
  console.log(JSON.stringify({ stage: 'encrypted-sqlite', status: 'running' }));
  
  let db;
  try {
    db = openEncryptedSqlite({ filename: dbPath, key: retrievedDb.bytes });
    
    // Apply a simple test migration
    db.applyMigrations([{
      name: '0001_test.sql',
      sql: 'CREATE TABLE IF NOT EXISTS test_proof (id INTEGER PRIMARY KEY, value TEXT);'
    }]);
    
    // Insert and read
    db.run('INSERT INTO test_proof (value) VALUES (?)', ['proof-value']);
    const row = db.first('SELECT value FROM test_proof WHERE id = ?', [1]);
    
    if (row?.value !== 'proof-value') {
      throw new Error('data-mismatch');
    }
    
    results.encryptedSqlite = 'OK';
    console.log(JSON.stringify({ stage: 'encrypted-sqlite', status: 'OK' }));
  } catch (err) {
    console.log(JSON.stringify({ stage: 'encrypted-sqlite', status: 'FAIL', reason: err.message }));
    process.exit(1);
  } finally {
    db?.close();
  }
  
  // 4. Encrypted audio store
  console.log(JSON.stringify({ stage: 'audio-store', status: 'running' }));
  
  try {
    const audioStore = await createFileAudioStore(audioDir, retrievedFile);
    
    // Verify directory was created
    await access(audioDir, constants.R_OK | constants.W_OK);
    
    results.audioStore = 'OK';
    console.log(JSON.stringify({ stage: 'audio-store', status: 'OK' }));
  } catch (err) {
    console.log(JSON.stringify({ stage: 'audio-store', status: 'FAIL', reason: err.message }));
    process.exit(1);
  }
  
  // 5. Scheduler tick
  console.log(JSON.stringify({ stage: 'scheduler', status: 'running' }));
  
  let tickCount = 0;
  const scheduler = createNodeScheduler(
    async (jobName) => { tickCount++; },
    (failure) => { console.error('scheduler failure:', failure); }
  );
  
  try {
    // Schedule a job that runs every second for testing
    await scheduler.schedule('test_job', '* * * * * *');
    
    // Wait for one tick (max 2 seconds)
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    if (tickCount === 0) {
      console.log(JSON.stringify({ stage: 'scheduler', status: 'FAIL', reason: 'no-tick' }));
      process.exit(1);
    }
    
    results.scheduler = 'OK';
    console.log(JSON.stringify({ stage: 'scheduler', status: 'OK', ticks: tickCount }));
  } finally {
    await scheduler.close();
  }
  
  // 6. Identity creation and bearer verification
  console.log(JSON.stringify({ stage: 'identity', status: 'running' }));
  
  const identity = createLocalSingleIdentity({
    interactiveUsername: 'TestProofUser',
    orgId: 'proof-org-123',
  });
  
  try {
    // Verify bearer format (no key material exposure)
    if (!identity.bearer.startsWith('CCC-LOCAL-SINGLEv1-')) {
      console.log(JSON.stringify({ stage: 'identity', status: 'FAIL', reason: 'invalid-bearer-prefix' }));
      process.exit(1);
    }
    
    // Verify stable user ID (no raw username)
    if (identity.stableUserId.includes('TestProofUser') || identity.stableUserId.includes('testproofuser')) {
      console.log(JSON.stringify({ stage: 'identity', status: 'FAIL', reason: 'raw-username-in-id' }));
      process.exit(1);
    }
    
    // Create request with bearer
    const request = new Request('http://127.0.0.1:9999/test', {
      headers: { authorization: 'Bearer ' + identity.bearer }
    });
    
    const actor = await identity.resolve(request);
    
    if (actor.kind !== 'human' || actor.userId !== identity.stableUserId) {
      console.log(JSON.stringify({ stage: 'identity', status: 'FAIL', reason: 'actor-mismatch' }));
      process.exit(1);
    }
    
    results.identity = 'OK';
    console.log(JSON.stringify({ stage: 'identity', status: 'OK' }));
  } finally {
    identity.close();
  }
  
  // 7. Write and verify endpoint record permissions
  console.log(JSON.stringify({ stage: 'endpoint-record', status: 'running' }));
  
  const endpointRecord = { installationId: 'proof-install-123', port: 12345 };
  await writeFile(endpointPath, JSON.stringify(endpointRecord), { mode: 0o600 });
  
  try {
    const stats = await stat(endpointPath);
    
    // On Windows, check that file exists and is readable
    await access(endpointPath, constants.R_OK);
    
    const content = await readFile(endpointPath, 'utf-8');
    const parsed = JSON.parse(content);
    
    if (parsed.installationId !== 'proof-install-123' || parsed.port !== 12345) {
      console.log(JSON.stringify({ stage: 'endpoint-record', status: 'FAIL', reason: 'content-mismatch' }));
      process.exit(1);
    }
    
    results.endpointRecord = 'OK';
    console.log(JSON.stringify({ stage: 'endpoint-record', status: 'OK' }));
  } catch (err) {
    console.log(JSON.stringify({ stage: 'endpoint-record', status: 'FAIL', reason: err.message }));
    process.exit(1);
  }
  
  // 8. Zero all key material
  console.log(JSON.stringify({ stage: 'cleanup-keys', status: 'running' }));
  
  retrievedDb.bytes.fill(0);
  retrievedFile.bytes.fill(0);
  retrievedPii.bytes.fill(0);
  store.close();
  
  results.cleanupKeys = 'OK';
  console.log(JSON.stringify({ stage: 'cleanup-keys', status: 'OK' }));
  
  // Final summary
  console.log(JSON.stringify({ stage: 'summary', status: 'OK', results }));
}

runProof().catch(err => {
  console.log(JSON.stringify({ stage: 'proof', status: 'FAIL', reason: err.message }));
  process.exit(1);
});
"@
    
    $proofPath = Join-Path $tempDir 'run-proof.mjs'
    Set-Content -Path $proofPath -Value $proofScript -Encoding UTF8
    
    $proofResult = & node $proofPath $dataDir 2>&1
    $proofResult | ForEach-Object { Write-Host $_ }
    
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='local-service-proof'; status='FAIL'; reason='proof-script-failed' }
      exit 1
    }
    
    Write-Status @{ stage='local-service-proof'; status='OK' }
  } finally {
    Pop-Location
  }
  
  # Run local-service unit tests
  Write-Stage "local-service-tests"
  Push-Location (Join-Path $tempDir 'apps/local-service')
  try {
    $testResult = & node --test test/contract.test.ts 2>&1
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='local-service-tests'; status='FAIL'; reason='tests-failed' }
      exit 1
    }
    Write-Status @{ stage='local-service-tests'; status='OK' }
  } finally {
    Pop-Location
  }
  
  Write-Stage "complete"
  Write-Status @{ stage='complete'; status='OK'; commit='7a2fc29' }
  
} finally {
  # Cleanup
  Write-Stage "cleanup"
  if (Test-Path $tempDir) {
    Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
  }
  Write-Status @{ stage='cleanup'; status='OK' }
}
