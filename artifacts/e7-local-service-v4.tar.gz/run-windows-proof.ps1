<# 
  E7-1a/E7-1b Local Single service Windows verification
  
  Exercises:
    - DPAPI record protect/unprotect
    - Encrypted SQLite open with real key material
    - Scheduler tick
    - Endpoint-record file permissions
    - Loopback HTTP server on ephemeral port
  
  Outputs JSON status lines only. Never prints key material, bearer tokens,
  ports with tokens, or raw SIDs.
  
  Usage: .\run-windows-proof.ps1 -Root C:\temp
  
  The -Root is a WORK directory (not the bundle). The script copies the bundle there.
  On failure, the temp directory is preserved for diagnosis.
#>
param(
    [Parameter(Mandatory=$true)]
    [string]$Root
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Write-Status { 
    param([hashtable]$Status) 
    Write-Host (ConvertTo-Json $Status -Compress -Depth 10) 
}

function Get-DirListing {
    param([string]$Dir)
    if (Test-Path -LiteralPath $Dir) {
        $items = Get-ChildItem -LiteralPath $Dir -ErrorAction SilentlyContinue | 
            Select-Object -ExpandProperty Name
        return ($items -join ', ')
    }
    return '(not found)'
}

# Global state
$completedStages = @()
$tempDir = $null
$preserveOnFail = $true

# Validate ASCII root
Write-Status @{ stage='validate'; status='running' }
if ($Root -match '[^\x20-\x7E]') {
    Write-Status @{ stage='validate'; status='FAIL'; reason='non-ascii-root' }
    exit 1
}

# Normalize paths
$rootPath = (Resolve-Path -LiteralPath $Root -ErrorAction SilentlyContinue)
if (-not $rootPath) {
    # Create root if it doesn't exist
    New-Item -ItemType Directory -Path $Root -Force | Out-Null
    $rootPath = (Resolve-Path -LiteralPath $Root).Path
} else {
    $rootPath = $rootPath.Path
}
$rootPath = $rootPath.TrimEnd([IO.Path]::DirectorySeparatorChar)

$bundleRoot = $PSScriptRoot
if (-not $bundleRoot) {
    $bundleRoot = (Get-Location).Path
}
$bundleRoot = (Resolve-Path -LiteralPath $bundleRoot).Path.TrimEnd([IO.Path]::DirectorySeparatorChar)

# Verify bundle contents
$bundlePackageJson = Join-Path $bundleRoot 'package.json'
if (-not (Test-Path -LiteralPath $bundlePackageJson)) {
    Write-Status @{ stage='validate'; status='FAIL'; reason='bundle-missing-package-json'; bundleRoot=$bundleRoot }
    exit 1
}

# Path containment check
$sep = [IO.Path]::DirectorySeparatorChar
if ($rootPath.StartsWith($bundleRoot + $sep) -or $rootPath -eq $bundleRoot) {
    Write-Status @{ stage='validate'; status='FAIL'; reason='root-inside-bundle' }
    exit 1
}
if ($bundleRoot.StartsWith($rootPath + $sep)) {
    Write-Status @{ stage='validate'; status='FAIL'; reason='bundle-inside-root' }
    exit 1
}

Write-Status @{ stage='validate'; status='OK' }
$completedStages += 'validate'

try {
    # Setup temp directory
    Write-Status @{ stage='setup'; status='running' }
    $timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $tempDir = Join-Path $rootPath "e7-proof-$timestamp"
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    Write-Status @{ stage='setup'; status='OK'; tempDir=$tempDir }
    $completedStages += 'setup'

    # Copy source using robocopy for reliable recursive copy
    Write-Status @{ stage='copy-source'; status='running' }
    
    # Use robocopy with /E (recursive) /NFL /NDL /NJH /NJS (quiet) /R:1 /W:1 (minimal retry)
    # Exclude the proof script itself
    $robocopyArgs = @(
        $bundleRoot,
        $tempDir,
        '/E',           # Copy subdirectories including empty ones
        '/NFL',         # No file list
        '/NDL',         # No directory list  
        '/NJH',         # No job header
        '/NJS',         # No job summary
        '/R:1',         # 1 retry
        '/W:1',         # 1 second wait
        '/XF', 'run-windows-proof.ps1',  # Exclude proof script
        '/XF', '._*',   # Exclude AppleDouble
        '/XF', '.DS_Store'  # Exclude macOS metadata
    )
    
    $robocopyResult = & robocopy @robocopyArgs
    $robocopyExit = $LASTEXITCODE
    
    # robocopy exit codes: 0-7 are success (bits indicate what was copied)
    # 8+ are errors
    if ($robocopyExit -ge 8) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='copy-source'; 
            status='FAIL'; 
            reason='robocopy-failed'; 
            exitCode=$robocopyExit;
            tempDirListing=$listing
        }
        exit 1
    }
    
    # Count copied items
    $copiedFiles = (Get-ChildItem -LiteralPath $tempDir -Recurse -File -ErrorAction SilentlyContinue | Measure-Object).Count
    $copiedDirs = (Get-ChildItem -LiteralPath $tempDir -Recurse -Directory -ErrorAction SilentlyContinue | Measure-Object).Count
    
    Write-Status @{ 
        stage='copy-source'; 
        status='OK'; 
        filesCopied=$copiedFiles; 
        dirsCopied=$copiedDirs 
    }
    $completedStages += 'copy-source'

    # Verify package.json exists in temp before install
    Write-Status @{ stage='verify-copy'; status='running' }
    $tempPackageJson = Join-Path $tempDir 'package.json'
    if (-not (Test-Path -LiteralPath $tempPackageJson)) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='verify-copy'; 
            status='FAIL'; 
            reason='package-json-not-copied';
            tempDirListing=$listing
        }
        exit 1
    }
    
    # Verify other key files
    $requiredFiles = @('pnpm-lock.yaml', 'pnpm-workspace.yaml', 'tsconfig.base.json')
    $missingFiles = @()
    foreach ($f in $requiredFiles) {
        $fPath = Join-Path $tempDir $f
        if (-not (Test-Path -LiteralPath $fPath)) {
            $missingFiles += $f
        }
    }
    if ($missingFiles.Count -gt 0) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='verify-copy'; 
            status='FAIL'; 
            reason='missing-required-files';
            missingFiles=($missingFiles -join ', ');
            tempDirListing=$listing
        }
        exit 1
    }
    
    Write-Status @{ stage='verify-copy'; status='OK' }
    $completedStages += 'verify-copy'

    # Install dependencies
    Write-Status @{ stage='install'; status='running'; cwd=$tempDir }
    
    # Change to temp directory and run pnpm
    Push-Location -LiteralPath $tempDir
    try {
        # Verify we're in the right directory
        $currentDir = (Get-Location).Path
        $currentPackageJson = Join-Path $currentDir 'package.json'
        if (-not (Test-Path -LiteralPath $currentPackageJson)) {
            $listing = Get-DirListing $currentDir
            Write-Status @{ 
                stage='install'; 
                status='FAIL'; 
                reason='cwd-missing-package-json';
                cwd=$currentDir;
                cwdListing=$listing
            }
            exit 1
        }
        
        $pnpmResult = & pnpm install --frozen-lockfile --ignore-scripts 2>&1
        $pnpmExit = $LASTEXITCODE
        
        if ($pnpmExit -ne 0) {
            $listing = Get-DirListing $tempDir
            # Truncate pnpm output to avoid huge JSON
            $pnpmOutput = ($pnpmResult | Out-String).Trim()
            if ($pnpmOutput.Length -gt 500) {
                $pnpmOutput = $pnpmOutput.Substring(0, 500) + '...(truncated)'
            }
            Write-Status @{ 
                stage='install'; 
                status='FAIL'; 
                reason='pnpm-install-failed';
                exitCode=$pnpmExit;
                cwd=$currentDir;
                tempDirListing=$listing;
                pnpmOutput=$pnpmOutput
            }
            exit 1
        }
    } finally {
        Pop-Location
    }
    
    Write-Status @{ stage='install'; status='OK' }
    $completedStages += 'install'

    # Build native DPAPI addon
    Write-Status @{ stage='build-native'; status='running' }
    
    Push-Location -LiteralPath $tempDir
    try {
        # Write the build script to a file to avoid escaping issues
        $buildScript = @"
import { execSync } from 'child_process';
import { join } from 'path';
const adapterDir = join(process.cwd(), 'adapters', 'secrets-dpapi');
process.chdir(adapterDir);
execSync('pnpm run build:native', { stdio: 'inherit' });
"@
        $buildScriptPath = Join-Path $tempDir '_build-native.mjs'
        Set-Content -LiteralPath $buildScriptPath -Value $buildScript -Encoding UTF8
        
        $buildResult = & npx tsx $buildScriptPath 2>&1
        $buildExit = $LASTEXITCODE
        
        Remove-Item -LiteralPath $buildScriptPath -Force -ErrorAction SilentlyContinue
        
        if ($buildExit -ne 0) {
            $listing = Get-DirListing $tempDir
            $buildOutput = ($buildResult | Out-String).Trim()
            if ($buildOutput.Length -gt 500) {
                $buildOutput = $buildOutput.Substring(0, 500) + '...(truncated)'
            }
            Write-Status @{ 
                stage='build-native'; 
                status='FAIL'; 
                reason='build-failed';
                exitCode=$buildExit;
                tempDirListing=$listing;
                buildOutput=$buildOutput
            }
            exit 1
        }
    } finally {
        Pop-Location
    }
    
    Write-Status @{ stage='build-native'; status='OK' }
    $completedStages += 'build-native'

    # Run DPAPI contract tests
    Write-Status @{ stage='dpapi-tests'; status='running' }
    
    Push-Location -LiteralPath $tempDir
    try {
        $testScript = @"
import { execSync } from 'child_process';
import { join } from 'path';
const adapterDir = join(process.cwd(), 'adapters', 'secrets-dpapi');
process.chdir(adapterDir);
execSync('pnpm test', { stdio: 'inherit' });
"@
        $testScriptPath = Join-Path $tempDir '_run-tests.mjs'
        Set-Content -LiteralPath $testScriptPath -Value $testScript -Encoding UTF8
        
        $testResult = & npx tsx $testScriptPath 2>&1
        $testExit = $LASTEXITCODE
        
        Remove-Item -LiteralPath $testScriptPath -Force -ErrorAction SilentlyContinue
        
        if ($testExit -ne 0) {
            $listing = Get-DirListing $tempDir
            $testOutput = ($testResult | Out-String).Trim()
            if ($testOutput.Length -gt 500) {
                $testOutput = $testOutput.Substring(0, 500) + '...(truncated)'
            }
            Write-Status @{ 
                stage='dpapi-tests'; 
                status='FAIL'; 
                reason='tests-failed';
                exitCode=$testExit;
                tempDirListing=$listing;
                testOutput=$testOutput
            }
            exit 1
        }
    } finally {
        Pop-Location
    }
    
    Write-Status @{ stage='dpapi-tests'; status='OK' }
    $completedStages += 'dpapi-tests'

    # Protect 3 keys with CurrentUser scope
    Write-Status @{ stage='dpapi-protect'; status='running' }
    
    Push-Location -LiteralPath $tempDir
    try {
        $protectScript = @"
import { protectData, unprotectData } from './adapters/secrets-dpapi/src/native.mjs';

const keys = ['DB_MASTER_KEY', 'PII_ENC_KEY', 'FILE_ENC_KEY'];
const results = [];

for (const name of keys) {
    const testData = new Uint8Array(32);
    crypto.getRandomValues(testData);
    
    const encrypted = protectData(testData, new Uint8Array(0), 'CurrentUser');
    if (!(encrypted instanceof Uint8Array) || encrypted.length === 0) {
        console.log(JSON.stringify({ key: name, status: 'FAIL', reason: 'protect-failed' }));
        process.exit(1);
    }
    
    const decrypted = unprotectData(encrypted, new Uint8Array(0), 'CurrentUser');
    if (!(decrypted instanceof Uint8Array) || decrypted.length !== 32) {
        console.log(JSON.stringify({ key: name, status: 'FAIL', reason: 'unprotect-failed' }));
        process.exit(1);
    }
    
    // Verify round-trip
    let match = true;
    for (let i = 0; i < 32; i++) {
        if (testData[i] !== decrypted[i]) { match = false; break; }
    }
    if (!match) {
        console.log(JSON.stringify({ key: name, status: 'FAIL', reason: 'data-mismatch' }));
        process.exit(1);
    }
    
    // Zero original (simulated - in real code this happens automatically)
    testData.fill(0);
    
    results.push({ key: name, status: 'OK', encryptedLen: encrypted.length });
}

console.log(JSON.stringify({ keys: results, status: 'OK' }));
"@
        $protectScriptPath = Join-Path $tempDir '_protect-test.mjs'
        Set-Content -LiteralPath $protectScriptPath -Value $protectScript -Encoding UTF8
        
        $protectResult = & npx tsx $protectScriptPath 2>&1
        $protectExit = $LASTEXITCODE
        
        Remove-Item -LiteralPath $protectScriptPath -Force -ErrorAction SilentlyContinue
        
        if ($protectExit -ne 0) {
            $listing = Get-DirListing $tempDir
            Write-Status @{ 
                stage='dpapi-protect'; 
                status='FAIL'; 
                reason='protect-script-failed';
                exitCode=$protectExit;
                tempDirListing=$listing
            }
            exit 1
        }
    } finally {
        Pop-Location
    }
    
    Write-Status @{ stage='dpapi-protect'; status='OK' }
    $completedStages += 'dpapi-protect'

    # Create store and retrieve keys
    Write-Status @{ stage='dpapi-store'; status='running' }
    
    Push-Location -LiteralPath $tempDir
    try {
        $storeDir = Join-Path $tempDir 'test-secrets'
        New-Item -ItemType Directory -Path $storeDir -Force | Out-Null
        
        $storeScript = @"
import { DpapiSecretStore } from './adapters/secrets-dpapi/src/store.ts';
import { join } from 'path';

const storeDir = process.argv[2];
const store = new DpapiSecretStore(storeDir);

// Store test keys
const keys = ['DB_MASTER_KEY', 'PII_ENC_KEY', 'FILE_ENC_KEY'];
for (const name of keys) {
    const value = new Uint8Array(32);
    crypto.getRandomValues(value);
    await store.set(name, value);
}

// Verify retrieval
for (const name of keys) {
    const value = await store.get(name);
    if (!value || value.length !== 32) {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'get-failed', key: name }));
        process.exit(1);
    }
}

// List keys
const names = await store.list();
if (names.length !== 3) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'list-mismatch', expected: 3, got: names.length }));
    process.exit(1);
}

console.log(JSON.stringify({ status: 'OK', storedKeys: names.length }));
"@
        $storeScriptPath = Join-Path $tempDir '_store-test.mjs'
        Set-Content -LiteralPath $storeScriptPath -Value $storeScript -Encoding UTF8
        
        $storeResult = & npx tsx $storeScriptPath $storeDir 2>&1
        $storeExit = $LASTEXITCODE
        
        Remove-Item -LiteralPath $storeScriptPath -Force -ErrorAction SilentlyContinue
        
        if ($storeExit -ne 0) {
            $listing = Get-DirListing $tempDir
            Write-Status @{ 
                stage='dpapi-store'; 
                status='FAIL'; 
                reason='store-script-failed';
                exitCode=$storeExit;
                tempDirListing=$listing
            }
            exit 1
        }
    } finally {
        Pop-Location
    }
    
    Write-Status @{ stage='dpapi-store'; status='OK' }
    $completedStages += 'dpapi-store'

    # Open encrypted SQLite
    Write-Status @{ stage='encrypted-sqlite'; status='running' }
    
    Push-Location -LiteralPath $tempDir
    try {
        $dbPath = Join-Path $tempDir 'test.db'
        
        $sqliteScript = @"
import { createDatabase } from './adapters/db-sqlite/src/index.ts';
import { readFileSync } from 'fs';
import { join } from 'path';

const dbPath = process.argv[2];
const migrationsDir = join(process.cwd(), 'migrations', 'sqlite');

// Generate encryption key
const key = new Uint8Array(32);
crypto.getRandomValues(key);

// Create encrypted database
const db = await createDatabase(dbPath, key);

// Run a subset of migrations (just init to verify it works)
const initSql = readFileSync(join(migrationsDir, '0001_init.sql'), 'utf-8');
await db.run(initSql);

// Insert and read test data
await db.run("INSERT INTO organizations (id, name, created_at) VALUES (?, ?, ?)", 
    ['test-org', 'Test Organization', new Date().toISOString()]);

const row = await db.first("SELECT name FROM organizations WHERE id = ?", ['test-org']);
if (!row || row.name !== 'Test Organization') {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'read-mismatch' }));
    process.exit(1);
}

await db.close();
console.log(JSON.stringify({ status: 'OK', dbPath: dbPath }));
"@
        $sqliteScriptPath = Join-Path $tempDir '_sqlite-test.mjs'
        Set-Content -LiteralPath $sqliteScriptPath -Value $sqliteScript -Encoding UTF8
        
        $sqliteResult = & npx tsx $sqliteScriptPath $dbPath 2>&1
        $sqliteExit = $LASTEXITCODE
        
        Remove-Item -LiteralPath $sqliteScriptPath -Force -ErrorAction SilentlyContinue
        
        if ($sqliteExit -ne 0) {
            $listing = Get-DirListing $tempDir
            $sqliteOutput = ($sqliteResult | Out-String).Trim()
            if ($sqliteOutput.Length -gt 500) {
                $sqliteOutput = $sqliteOutput.Substring(0, 500) + '...(truncated)'
            }
            Write-Status @{ 
                stage='encrypted-sqlite'; 
                status='FAIL'; 
                reason='sqlite-script-failed';
                exitCode=$sqliteExit;
                tempDirListing=$listing;
                output=$sqliteOutput
            }
            exit 1
        }
    } finally {
        Pop-Location
    }
    
    Write-Status @{ stage='encrypted-sqlite'; status='OK' }
    $completedStages += 'encrypted-sqlite'

    # Create encrypted audio directory
    Write-Status @{ stage='audio-store'; status='running' }
    
    Push-Location -LiteralPath $tempDir
    try {
        $audioDir = Join-Path $tempDir 'test-audio'
        
        $audioScript = @"
import { FileAudioStore } from './adapters/audio-file/src/index.ts';
import { join } from 'path';

const audioDir = process.argv[2];

// Generate encryption key
const key = new Uint8Array(32);
crypto.getRandomValues(key);

const store = new FileAudioStore(audioDir, key);
await store.initialize();

// Create test audio data
const testAudio = new Uint8Array(1024);
crypto.getRandomValues(testAudio);

// Store it
const id = 'test-session-001';
await store.put(id, testAudio, { contentType: 'audio/wav', expiresAt: new Date(Date.now() + 86400000).toISOString() });

// Retrieve it
const retrieved = await store.get(id);
if (!retrieved || retrieved.body.length !== 1024) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'audio-mismatch' }));
    process.exit(1);
}

console.log(JSON.stringify({ status: 'OK', audioDir: audioDir }));
"@
        $audioScriptPath = Join-Path $tempDir '_audio-test.mjs'
        Set-Content -LiteralPath $audioScriptPath -Value $audioScript -Encoding UTF8
        
        $audioResult = & npx tsx $audioScriptPath $audioDir 2>&1
        $audioExit = $LASTEXITCODE
        
        Remove-Item -LiteralPath $audioScriptPath -Force -ErrorAction SilentlyContinue
        
        if ($audioExit -ne 0) {
            $listing = Get-DirListing $tempDir
            Write-Status @{ 
                stage='audio-store'; 
                status='FAIL'; 
                reason='audio-script-failed';
                exitCode=$audioExit;
                tempDirListing=$listing
            }
            exit 1
        }
    } finally {
        Pop-Location
    }
    
    Write-Status @{ stage='audio-store'; status='OK' }
    $completedStages += 'audio-store'

    # Wait for one scheduler tick
    Write-Status @{ stage='scheduler'; status='running' }
    
    Push-Location -LiteralPath $tempDir
    try {
        $schedulerScript = @"
import { NodeScheduler } from './adapters/scheduler-node/src/index.ts';

const scheduler = new NodeScheduler();
let ticked = false;

scheduler.schedule('* * * * * *', () => {
    ticked = true;
});

scheduler.start();

// Wait up to 2 seconds for a tick
await new Promise(resolve => setTimeout(resolve, 2000));

scheduler.stop();

if (!ticked) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'no-tick' }));
    process.exit(1);
}

console.log(JSON.stringify({ status: 'OK' }));
"@
        $schedulerScriptPath = Join-Path $tempDir '_scheduler-test.mjs'
        Set-Content -LiteralPath $schedulerScriptPath -Value $schedulerScript -Encoding UTF8
        
        $schedulerResult = & npx tsx $schedulerScriptPath 2>&1
        $schedulerExit = $LASTEXITCODE
        
        Remove-Item -LiteralPath $schedulerScriptPath -Force -ErrorAction SilentlyContinue
        
        if ($schedulerExit -ne 0) {
            $listing = Get-DirListing $tempDir
            Write-Status @{ 
                stage='scheduler'; 
                status='FAIL'; 
                reason='scheduler-script-failed';
                exitCode=$schedulerExit;
                tempDirListing=$listing
            }
            exit 1
        }
    } finally {
        Pop-Location
    }
    
    Write-Status @{ stage='scheduler'; status='OK' }
    $completedStages += 'scheduler'

    # Create bearer and verify stable user ID
    Write-Status @{ stage='identity'; status='running' }
    
    Push-Location -LiteralPath $tempDir
    try {
        $identityScript = @"
import { createLocalIdentity } from './apps/local-service/src/identity.ts';

const identity = await createLocalIdentity();

// Verify stable user ID exists and doesn't contain raw username
const userId = identity.getStableUserId();
if (!userId || typeof userId !== 'string' || userId.length < 10) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'invalid-user-id' }));
    process.exit(1);
}

// Create bearer token
const bearer = identity.createBearer();
if (!bearer || typeof bearer !== 'string' || bearer.length < 32) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'invalid-bearer' }));
    process.exit(1);
}

// Resolve actor
const actor = await identity.resolveActor(bearer);
if (!actor || actor.userId !== userId) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'actor-mismatch' }));
    process.exit(1);
}

console.log(JSON.stringify({ status: 'OK', userIdLength: userId.length }));
"@
        $identityScriptPath = Join-Path $tempDir '_identity-test.mjs'
        Set-Content -LiteralPath $identityScriptPath -Value $identityScript -Encoding UTF8
        
        $identityResult = & npx tsx $identityScriptPath 2>&1
        $identityExit = $LASTEXITCODE
        
        Remove-Item -LiteralPath $identityScriptPath -Force -ErrorAction SilentlyContinue
        
        if ($identityExit -ne 0) {
            $listing = Get-DirListing $tempDir
            Write-Status @{ 
                stage='identity'; 
                status='FAIL'; 
                reason='identity-script-failed';
                exitCode=$identityExit;
                tempDirListing=$listing
            }
            exit 1
        }
    } finally {
        Pop-Location
    }
    
    Write-Status @{ stage='identity'; status='OK' }
    $completedStages += 'identity'

    # Write and verify endpoint.json permissions
    Write-Status @{ stage='endpoint-record'; status='running' }
    
    $endpointPath = Join-Path $tempDir 'endpoint.json'
    $endpointData = @{
        host = '127.0.0.1'
        port = 0  # Ephemeral
        mode = 'local-single'
        created = (Get-Date).ToUniversalTime().ToString('o')
    }
    $endpointData | ConvertTo-Json | Set-Content -LiteralPath $endpointPath -Encoding UTF8
    
    # Verify file exists and is readable
    if (-not (Test-Path -LiteralPath $endpointPath)) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='endpoint-record'; 
            status='FAIL'; 
            reason='file-not-created';
            tempDirListing=$listing
        }
        exit 1
    }
    
    $content = Get-Content -LiteralPath $endpointPath -Raw | ConvertFrom-Json
    if ($content.host -ne '127.0.0.1' -or $content.mode -ne 'local-single') {
        Write-Status @{ stage='endpoint-record'; status='FAIL'; reason='content-mismatch' }
        exit 1
    }
    
    Write-Status @{ stage='endpoint-record'; status='OK' }
    $completedStages += 'endpoint-record'

    # All stages passed - clean up
    $preserveOnFail = $false
    Write-Status @{ stage='cleanup'; status='running' }
    
    if (Test-Path -LiteralPath $tempDir) {
        Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
    
    Write-Status @{ stage='cleanup'; status='OK'; completedStages=$completedStages; allPassed=$true }
    exit 0

} catch {
    $listing = if ($tempDir) { Get-DirListing $tempDir } else { '(no tempDir)' }
    Write-Status @{ 
        stage='error'; 
        status='FAIL'; 
        reason=$_.Exception.Message;
        completedStages=$completedStages;
        tempDirListing=$listing;
        preservedTempDir=$tempDir
    }
    # Don't clean up on failure
    exit 1
}
