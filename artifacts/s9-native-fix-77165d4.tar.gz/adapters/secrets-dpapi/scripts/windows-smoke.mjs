import assert from 'node:assert/strict';
import { createDpapiSecretStore } from '../src/index.ts';
import { createProtectedRecordRepository } from '../src/record-file.ts';
import { createPrivateFiles } from '../src/private-files.ts';
import { sealRecoveryKit, openRecoveryKit, wipeCbor } from '../src/recovery-kit.ts';
import { mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

// Bundle-only synthetic proof. Private ACLs and ciphertext exist only inside its new temporary directory. No existing accounts, permissions or credentials change.
const stores = [];
const buffers = [];
let parent;
let stage = 'platform';
try {
  if (process.argv[2] === '--expect-unbuilt') {
    assert.throws(() => createDpapiSecretStore('local-single', []), /^Error: secret_access_denied$/);
    console.log(JSON.stringify({ status: 'unbuilt-loader-refused', platform: process.platform, node: process.version }));
  } else {
    assert.equal(process.platform, 'win32');
    stage = 'native_load';
    const writer = createDpapiSecretStore('local-single', []); stores.push(writer);
    const synthetic = new Uint8Array(32).fill(25); buffers.push(synthetic);
    stage = 'protect_records';
    const records = ['DB_MASTER_KEY', 'FILE_ENC_KEY', 'PII_ENC_KEY'].map(name => writer.protect(name, { bytes: synthetic, version: 3 }));
    buffers.push(...records.map(record => record.blob));
    parent = await mkdtemp(join(tmpdir(), 'ccc-s9-native-proof-'));
    const root = join(parent, 'private');
    stage = 'create_repository';
    const repository = await createProtectedRecordRepository(root, 'local-single');
    stage = 'stage_generation';
    const digest = await repository.stage(7, records);
    stage = 'reopen_repository';
    const reopened = await createProtectedRecordRepository(root, 'local-single');
    stage = 'read_generation';
    const persisted = await reopened.read(7, digest); buffers.push(...persisted.map(record => record.blob));
    stage = 'open_byte_store';
    const reader = createDpapiSecretStore('local-single', persisted); stores.push(reader);
    stage = 'read_keys';
    for (const record of records) {
      const first = await reader.getBytesWithVersion(record.name); buffers.push(first.bytes);
      assert.equal(first.version, 3);
      assert.equal(Object.getPrototypeOf(first.bytes), Uint8Array.prototype);
      assert.deepEqual(first.bytes, synthetic);
      first.bytes.fill(0);
      const second = await reader.getBytesWithVersion(record.name); buffers.push(second.bytes);
      assert.deepEqual(second.bytes, synthetic);
    }
    stage = 'metadata_refusal';
    const swapped = createDpapiSecretStore('local-single', [{ ...records[0], version: 4 }]); stores.push(swapped);
    await assert.rejects(swapped.getBytesWithVersion('DB_MASTER_KEY'), /^Error: secret_access_denied$/);
    reader.close();
    await assert.rejects(reader.getBytesWithVersion('DB_MASTER_KEY'), /^Error: secret_access_denied$/);
    assert.deepEqual(synthetic, new Uint8Array(32).fill(25));
    const binding = {schemaVersion:44,schemaDigest:new Uint8Array(32).fill(1),mode:'local-single',kitId:'synthetic-kit',s10PayloadSha256:new Uint8Array(32).fill(2),sourceInstallationId:'synthetic-install',sourceOrgId:null,createdAt:'2026-07-16T00:00:00.000Z'};
    const payload = {...binding,schemaDigest:new Uint8Array(binding.schemaDigest),s10PayloadSha256:new Uint8Array(binding.s10PayloadSha256),payloadVersion:1,generation:7,previousKitHash:null,stableUserId:'synthetic-user',dbMasterKey:{key:new Uint8Array(synthetic),version:3},fileMasterKey:{key:new Uint8Array(synthetic),version:3},piiEncKey:{key:new Uint8Array(synthetic),version:3},officeCaKey:null,identityContinuity:{mode:'local-single',stableUserId:'synthetic-user',actors:[]}};
    const phrase = () => new TextEncoder().encode('synthetic qualification phrase');
    stage = 'seal_envelope';
    const wire = await sealRecoveryKit(payload, phrase());
    stage = 'publish_envelope';
    const files = await createPrivateFiles(root); await files.publish('synthetic.cccr', wire);
    stage = 'open_envelope';
    const clear = await openRecoveryKit(await files.read('synthetic.cccr'), phrase(), binding);
    try { assert.deepEqual(clear.piiEncKey.key, synthetic); assert.equal(clear.piiEncKey.version, 3); } finally { wipeCbor(clear); }
    console.log(JSON.stringify({status:'synthetic-public-storage-envelope-verified',platform:process.platform,arch:process.arch,node:process.version,keys:3,stagedPersistence:true,recoveryEnvelope:true,generationActivation:false,operationalRestore:false}));
  }
} catch {
  console.error(`smoke_stage=${stage}`);
  console.error('secret_access_denied');
  process.exitCode = 1;
} finally {
  for (const store of stores) store.close();
  for (const buffer of buffers) buffer.fill(0);
  if (parent) await rm(parent, {recursive:true,force:true});
}
