# E7 Windows verification bundle v12
# - Compile adapters to JavaScript before tests
# - Uses compiled JavaScript from dist/ for production parity
# - Uses stableUserId config instead of interactiveUsername
# - Verifies: DPAPI native binding, secrets store, encrypted SQLite, 
#   encrypted file AudioStore, Node scheduler, Local Single identity
#
# Expected Node version: 22.x LTS with --experimental-strip-types
# PowerShell 5.1+ required

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# ── Helpers ───────────────────────────────────────────────────────────────────

function Write-Status($obj) {
    $json = $obj | ConvertTo-Json -Compress -Depth 10
    Write-Output $json
}

function Get-DirListing($path) {
    if (-not (Test-Path $path)) { return @() }
    Get-ChildItem -LiteralPath $path -Recurse -Force -ErrorAction SilentlyContinue |
        ForEach-Object { $_.FullName.Replace($path, '.') }
}

function Invoke-NodeWithOutput {
    param(
        [string[]]$ArgumentList,
        [string]$WorkingDirectory
    )
    
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = 'node'
    $psi.Arguments = (@('--experimental-strip-types') + $ArgumentList) -join ' '
    $psi.WorkingDirectory = $WorkingDirectory
    $psi.RedirectStandardOutput = $true
    $psi.RedirectStandardError = $true
    $psi.UseShellExecute = $false
    $psi.CreateNoWindow = $true
    
    $process = [System.Diagnostics.Process]::Start($psi)
    $stdout = $process.StandardOutput.ReadToEnd()
    $stderr = $process.StandardError.ReadToEnd()
    $process.WaitForExit()
    
    return @{
        ExitCode = $process.ExitCode
        Stdout = $stdout
        Stderr = $stderr
    }
}

$completedStages = @()

# ── Stage: validate ───────────────────────────────────────────────────────────
Write-Status @{ stage='validate'; status='running' }

# Verify we're on Windows
if ($env:OS -ne 'Windows_NT') {
    Write-Status @{ stage='validate'; status='FAIL'; reason='not-windows'; os=$env:OS }
    exit 1
}

# Verify Node >= 22
try {
    $nodeVersion = (node --version) -replace '^v', ''
    $major = [int]($nodeVersion.Split('.')[0])
    if ($major -lt 22) {
        Write-Status @{ stage='validate'; status='FAIL'; reason='node-version'; nodeVersion=$nodeVersion }
        exit 1
    }
} catch {
    Write-Status @{ stage='validate'; status='FAIL'; reason='node-check-failed'; error=$_.Exception.Message }
    exit 1
}

# Verify pnpm available
try {
    $pnpmVersion = pnpm --version
} catch {
    Write-Status @{ stage='validate'; status='FAIL'; reason='pnpm-not-found' }
    exit 1
}

Write-Status @{ stage='validate'; status='OK'; nodeVersion=$nodeVersion; pnpmVersion=$pnpmVersion }
$completedStages += 'validate'

# ── Stage: setup ──────────────────────────────────────────────────────────────
Write-Status @{ stage='setup'; status='running' }

# Create isolated temp directory
$timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$tempDir = Join-Path $env:TEMP "e7-proof-$timestamp"
New-Item -ItemType Directory -Path $tempDir -Force | Out-Null

# Store current location
$originalLocation = Get-Location

Write-Status @{ stage='setup'; status='OK'; tempDir=$tempDir }
$completedStages += 'setup'

# ── Stage: copy-source ────────────────────────────────────────────────────────
Write-Status @{ stage='copy-source'; status='running' }

# Get script directory (bundle root)
$bundleRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition

# Items to copy (relative paths from bundle root)
$copyItems = @(
    'adapters',
    'apps',
    'packages',
    'migrations',
    'patches',
    'package.json',
    'pnpm-lock.yaml',
    'pnpm-workspace.yaml',
    'tsconfig.base.json'
)

$fileCount = 0
$dirCount = 0

foreach ($item in $copyItems) {
    $srcPath = Join-Path $bundleRoot $item
    $destPath = Join-Path $tempDir $item
    
    if (Test-Path $srcPath -PathType Container) {
        Copy-Item -LiteralPath $srcPath -Destination $destPath -Recurse -Force
        $dirCount++
    } elseif (Test-Path $srcPath -PathType Leaf) {
        $destDir = Split-Path $destPath -Parent
        if (-not (Test-Path $destDir)) {
            New-Item -ItemType Directory -Path $destDir -Force | Out-Null
        }
        Copy-Item -LiteralPath $srcPath -Destination $destPath -Force
        $fileCount++
    }
}

# Count all files recursively
$totalFiles = (Get-ChildItem -LiteralPath $tempDir -Recurse -File).Count
$totalDirs = (Get-ChildItem -LiteralPath $tempDir -Recurse -Directory).Count

Write-Status @{ stage='copy-source'; status='OK'; files=$totalFiles; dirs=$totalDirs }
$completedStages += 'copy-source'

# ── Stage: verify-copy ────────────────────────────────────────────────────────
Write-Status @{ stage='verify-copy'; status='running' }

$requiredPaths = @(
    'adapters/secrets-dpapi/binding.gyp',
    'adapters/secrets-dpapi/src/native.mjs',
    'adapters/secrets-dpapi/src/store.ts',
    'adapters/secrets-dpapi/src/dpapi.cc',
    'adapters/db-sqlite/src/index.ts',
    'adapters/db-sqlite/dist/index.js',
    'adapters/db-sqlite/package.json',
    'adapters/audio-file/src/index.ts',
    'adapters/audio-file/dist/index.js',
    'adapters/audio-file/package.json',
    'adapters/scheduler-node/src/index.ts',
    'adapters/scheduler-node/dist/index.js',
    'adapters/scheduler-node/package.json',
    'apps/local-service/src/identity.ts',
    'apps/local-service/dist/identity.js',
    'apps/local-service/package.json',
    'packages/contracts/package.json'
)

$missing = @()
foreach ($path in $requiredPaths) {
    $fullPath = Join-Path $tempDir $path
    if (-not (Test-Path $fullPath)) {
        $missing += $path
    }
}

if ($missing.Count -gt 0) {
    Write-Status @{ stage='verify-copy'; status='FAIL'; reason='missing-files'; missing=$missing }
    exit 1
}

Write-Status @{ stage='verify-copy'; status='OK'; verified=$requiredPaths.Count }
$completedStages += 'verify-copy'

# ── Stage: install ────────────────────────────────────────────────────────────
Write-Status @{ stage='install'; status='running' }

Set-Location $tempDir

try {
    $installOutput = pnpm install --frozen-lockfile 2>&1 | Out-String
    if ($LASTEXITCODE -ne 0) {
        Write-Status @{ stage='install'; status='FAIL'; reason='pnpm-install-failed'; output=$installOutput }
        exit 1
    }
} catch {
    Write-Status @{ stage='install'; status='FAIL'; reason='pnpm-install-error'; error=$_.Exception.Message }
    exit 1
}

Write-Status @{ stage='install'; status='OK' }
$completedStages += 'install'

# ── Stage: build-native ───────────────────────────────────────────────────────
Write-Status @{ stage='build-native'; status='running' }

try {
    Set-Location (Join-Path $tempDir 'adapters/secrets-dpapi')
    $buildOutput = pnpm run build:native 2>&1 | Out-String
    if ($LASTEXITCODE -ne 0) {
        Write-Status @{ stage='build-native'; status='FAIL'; reason='build-failed'; output=$buildOutput }
        exit 1
    }
    Set-Location $tempDir
} catch {
    Write-Status @{ stage='build-native'; status='FAIL'; reason='build-error'; error=$_.Exception.Message }
    exit 1
}

# Verify the binding was built
$bindingPath = Join-Path $tempDir 'adapters/secrets-dpapi/build/Release/dpapi.node'
if (-not (Test-Path $bindingPath)) {
    $buildDir = Join-Path $tempDir 'adapters/secrets-dpapi/build'
    $listing = Get-DirListing $buildDir
    Write-Status @{ stage='build-native'; status='FAIL'; reason='no-binding'; buildDir=$listing }
    exit 1
}

Write-Status @{ stage='build-native'; status='OK'; binding=$bindingPath }
$completedStages += 'build-native'

# ── Stage: dpapi-tests ────────────────────────────────────────────────────────
Write-Status @{ stage='dpapi-tests'; status='running' }

# Use pnpm for test to ensure proper module resolution
try {
    Set-Location (Join-Path $tempDir 'adapters/secrets-dpapi')
    $testOutput = pnpm test 2>&1 | Out-String
    $testExitCode = $LASTEXITCODE
    Set-Location $tempDir
    
    if ($testExitCode -ne 0) {
        Write-Status @{ stage='dpapi-tests'; status='FAIL'; reason='tests-failed'; exitCode=$testExitCode; output=$testOutput }
        exit 1
    }
} catch {
    Write-Status @{ stage='dpapi-tests'; status='FAIL'; reason='test-error'; error=$_.Exception.Message }
    exit 1
}

Write-Status @{ stage='dpapi-tests'; status='OK' }
$completedStages += 'dpapi-tests'

# ── Stage: dpapi-protect ──────────────────────────────────────────────────────
Write-Status @{ stage='dpapi-protect'; status='running' }

# Test raw DPAPI protectData/unprotectData via the native binding
$protectScript = @'
import { loadNative } from './adapters/secrets-dpapi/src/native.mjs';

const native = loadNative();

// Test 1: Basic protect/unprotect round-trip
const testData = new Uint8Array([1, 2, 3, 4, 5, 6, 7, 8]);
const entropy = new Uint8Array([10, 20, 30, 40]);

const protected1 = native.protectData(testData, entropy);
if (!(protected1 instanceof Uint8Array) || protected1.length === 0) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'protect-failed' }));
    process.exit(1);
}

const unprotected1 = native.unprotectData(protected1, entropy);
if (!(unprotected1 instanceof Uint8Array) || unprotected1.length !== testData.length) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'unprotect-wrong-length' }));
    process.exit(1);
}

for (let i = 0; i < testData.length; i++) {
    if (unprotected1[i] !== testData[i]) {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'data-mismatch', index: i }));
        process.exit(1);
    }
}

// Test 2: Different entropy gives different ciphertext
const entropy2 = new Uint8Array([50, 60, 70, 80]);
const protected2 = native.protectData(testData, entropy2);

// Ciphertext should be different
let same = true;
for (let i = 0; i < Math.min(protected1.length, protected2.length); i++) {
    if (protected1[i] !== protected2[i]) { same = false; break; }
}
if (same && protected1.length === protected2.length) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'entropy-not-effective' }));
    process.exit(1);
}

// Test 3: Wrong entropy fails to unprotect
try {
    const wrongEntropy = new Uint8Array([99, 99, 99, 99]);
    native.unprotectData(protected1, wrongEntropy);
    console.log(JSON.stringify({ status: 'FAIL', reason: 'accepted-wrong-entropy' }));
    process.exit(1);
} catch (e) {
    // Expected: decryption should fail
}

// Verify hardening version exists
if (typeof native.cccHardeningVersion !== 'number') {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'no-hardening-version' }));
    process.exit(1);
}

console.log(JSON.stringify({ 
    status: 'OK', 
    packageRoot: native.packageRoot || 'unknown',
    hardeningVersion: native.cccHardeningVersion
}));
'@

$protectScriptPath = Join-Path $tempDir '_dpapi-protect.mjs'
Set-Content -LiteralPath $protectScriptPath -Value $protectScript -Encoding UTF8

$protectResult = Invoke-NodeWithOutput -ArgumentList @($protectScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $protectScriptPath -Force -ErrorAction SilentlyContinue

if ($protectResult.ExitCode -ne 0) {
    Write-Status @{ 
        stage='dpapi-protect'; status='FAIL'; reason='protect-script-failed';
        exitCode=$protectResult.ExitCode; stdout=$protectResult.Stdout; stderr=$protectResult.Stderr 
    }
    exit 1
}

Write-Status @{ stage='dpapi-protect'; status='OK' }
$completedStages += 'dpapi-protect'

# ── Stage: dpapi-store ────────────────────────────────────────────────────────
Write-Status @{ stage='dpapi-store'; status='running' }

# Test byteStore with the proper entropy format
$storeScript = @'
import { loadNative } from './adapters/secrets-dpapi/src/native.mjs';
import { byteStore } from './adapters/secrets-dpapi/src/store.ts';

const native = loadNative();

// Store for local-single mode
const store = byteStore(native, 'local-single', []);

// Test all valid key names
const keys = ['DB_MASTER_KEY', 'FILE_KEY', 'PII_ENC_KEY'];
const originalValues = new Map();

for (const name of keys) {
    // Generate a random 32-byte value
    const value = new Uint8Array(32);
    crypto.getRandomValues(value);
    originalValues.set(name, new Uint8Array(value));  // Copy before it gets wiped
    
    // Protect it
    const record = store.protect(name, { bytes: value, version: 1 });
    
    // Verify record structure
    if (!record || typeof record.name !== 'string' || !record.blob || typeof record.version !== 'number') {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'bad-record-structure', key: name }));
        process.exit(1);
    }
}

store.close();

// Collect all records for reloading
const records = [];
for (const name of keys) {
    const value = new Uint8Array(32);
    crypto.getRandomValues(value);
    originalValues.set(name, new Uint8Array(value));
    
    const tempStore = byteStore(native, 'local-single', []);
    const record = tempStore.protect(name, { bytes: value, version: 1 });
    records.push(record);
    tempStore.close();
}

// Create a new store with the protected records to read them back
const store2 = byteStore(native, 'local-single', records);
for (const name of keys) {
    const result = await store2.getBytesWithVersion(name);
    if (!result || result.bytes.length !== 32) {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'get-failed', key: name }));
        process.exit(1);
    }
    
    // Verify the decrypted value matches the original
    const original = originalValues.get(name);
    let match = true;
    for (let i = 0; i < 32; i++) {
        if (result.bytes[i] !== original[i]) { match = false; break; }
    }
    if (!match) {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'data-mismatch', key: name }));
        process.exit(1);
    }
    result.bytes.fill(0);
}
store2.close();

// Verify OFFICE_CA_KEY is rejected in local-single mode
const store3 = byteStore(native, 'local-single', []);
try {
    store3.protect('OFFICE_CA_KEY', { bytes: new Uint8Array(32), version: 1 });
    console.log(JSON.stringify({ status: 'FAIL', reason: 'accepted-office-key' }));
    process.exit(1);
} catch (e) {
    // Expected: office keys not allowed in local-single
}
store3.close();

console.log(JSON.stringify({ status: 'OK', keysProtected: keys.length }));
'@

$storeScriptPath = Join-Path $tempDir '_dpapi-store.mjs'
Set-Content -LiteralPath $storeScriptPath -Value $storeScript -Encoding UTF8

$storeResult = Invoke-NodeWithOutput -ArgumentList @($storeScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $storeScriptPath -Force -ErrorAction SilentlyContinue

if ($storeResult.ExitCode -ne 0) {
    Write-Status @{ 
        stage='dpapi-store'; status='FAIL'; reason='store-script-failed';
        exitCode=$storeResult.ExitCode; stdout=$storeResult.Stdout; stderr=$storeResult.Stderr
    }
    exit 1
}

Write-Status @{ stage='dpapi-store'; status='OK' }
$completedStages += 'dpapi-store'

# ── Stage: encrypted-sqlite ───────────────────────────────────────────────────
# Use pre-compiled JavaScript from dist/ to avoid TypeScript parameter property issues
Write-Status @{ stage='encrypted-sqlite'; status='running' }

$sqliteScript = @'
import { loadNative } from './adapters/secrets-dpapi/src/native.mjs';
import { byteStore } from './adapters/secrets-dpapi/src/store.ts';
import { openEncryptedSqlite } from './adapters/db-sqlite/dist/index.js';
import { join } from 'node:path';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';

const native = loadNative();

// Generate a real 32-byte key via DPAPI
const keyBytes = new Uint8Array(32);
crypto.getRandomValues(keyBytes);
const store = byteStore(native, 'local-single', []);
const keyRecord = store.protect('DB_MASTER_KEY', { bytes: keyBytes, version: 1 });
store.close();

// Use the raw key for SQLite (in production this comes from the store)
const testDir = mkdtempSync(join(tmpdir(), 'e7-sqlite-'));
const dbPath = join(testDir, 'test.db');

try {
    const db = openEncryptedSqlite({ filename: dbPath, key: keyBytes });
    
    // Basic smoke test: create table, insert, select
    db.run('CREATE TABLE test (id INTEGER PRIMARY KEY, value TEXT)');
    db.run('INSERT INTO test (value) VALUES (?)', 'hello');
    const row = db.first('SELECT value FROM test WHERE id = 1');
    
    if (!row || row.value !== 'hello') {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'query-failed', row }));
        process.exit(1);
    }
    
    db.close();
    
    // Test 2: Reopen with same key should work
    const db2 = openEncryptedSqlite({ filename: dbPath, key: keyBytes });
    const row2 = db2.first('SELECT value FROM test WHERE id = 1');
    
    if (!row2 || row2.value !== 'hello') {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'reopen-failed', row2 }));
        process.exit(1);
    }
    
    db2.close();
    
    // Clean up key material
    keyBytes.fill(0);
    keyRecord.blob.fill(0);
    
    console.log(JSON.stringify({ status: 'OK', created: true, reopened: true }));
} finally {
    rmSync(testDir, { recursive: true, force: true });
}
'@

$sqliteScriptPath = Join-Path $tempDir '_encrypted-sqlite.mjs'
Set-Content -LiteralPath $sqliteScriptPath -Value $sqliteScript -Encoding UTF8

$sqliteResult = Invoke-NodeWithOutput -ArgumentList @($sqliteScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $sqliteScriptPath -Force -ErrorAction SilentlyContinue

if ($sqliteResult.ExitCode -ne 0) {
    $listing = Get-DirListing $tempDir
    Write-Status @{ 
        stage='encrypted-sqlite'; status='FAIL'; reason='sqlite-script-failed';
        exitCode=$sqliteResult.ExitCode; stdout=$sqliteResult.Stdout; stderr=$sqliteResult.Stderr;
        tempDirListing=$listing; preservedTempDir=$tempDir
    }
    exit 1
}

Write-Status @{ stage='encrypted-sqlite'; status='OK' }
$completedStages += 'encrypted-sqlite'

# ── Stage: audio-store ────────────────────────────────────────────────────────
Write-Status @{ stage='audio-store'; status='running' }

$audioScript = @'
// createFileAudioStore(rootPath: string, fileKey: VersionedSecretBytes): Promise<AudioStore>
// Use compiled JavaScript from dist/ for production parity
import { createFileAudioStore } from './adapters/audio-file/dist/index.js';
import { join } from 'node:path';
import { mkdtempSync, mkdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';

// Test 1: Basic functionality with system temp (may have non-ASCII in path on Windows)
const testDir1 = mkdtempSync(join(tmpdir(), 'e7-audio-'));
const fileKeyBytes = new Uint8Array(32);
crypto.getRandomValues(fileKeyBytes);
const fileKey = { bytes: fileKeyBytes, version: 1 };

try {
    const store1 = await createFileAudioStore(testDir1, fileKey);
    
    // Verify store has the expected AudioStore interface methods
    const requiredMethods = ['createUploadTarget', 'createDownloadTarget', 'delete', 'put', 'get'];
    for (const method of requiredMethods) {
        if (typeof store1[method] !== 'function') {
            console.log(JSON.stringify({ status: 'FAIL', reason: `no-${method}` }));
            process.exit(1);
        }
    }
    
    // Test 2: Explicitly test non-ASCII path (Korean, Japanese, emoji)
    // Use Unicode escapes so PowerShell doesn't mangle the characters when writing this file.
    // \uD14C\uC2A4\uD2B8 = Korean "test"
    // \u30C6\u30B9\u30C8 = Japanese "test"  
    // \uD83D\uDD10 = lock emoji (surrogate pair for U+1F510)
    const unicodeName = '\uD14C\uC2A4\uD2B8_\u30C6\u30B9\u30C8_\uD83D\uDD10';
    const unicodeSubdir = join(testDir1, unicodeName);
    mkdirSync(unicodeSubdir, { mode: 0o700 });
    
    const store2 = await createFileAudioStore(unicodeSubdir, fileKey);
    if (typeof store2.createUploadTarget !== 'function') {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'unicode-path-failed' }));
        process.exit(1);
    }
    
    console.log(JSON.stringify({ 
        status: 'OK', 
        hasInterface: true, 
        unicodePathWorked: true 
    }));
} finally {
    rmSync(testDir1, { recursive: true, force: true });
}
'@

$audioScriptPath = Join-Path $tempDir '_audio-store.mjs'
Set-Content -LiteralPath $audioScriptPath -Value $audioScript -Encoding UTF8

$audioResult = Invoke-NodeWithOutput -ArgumentList @($audioScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $audioScriptPath -Force -ErrorAction SilentlyContinue

if ($audioResult.ExitCode -ne 0) {
    $listing = Get-DirListing $tempDir
    Write-Status @{ 
        stage='audio-store'; status='FAIL'; reason='audio-script-failed';
        exitCode=$audioResult.ExitCode; stdout=$audioResult.Stdout; stderr=$audioResult.Stderr;
        tempDirListing=$listing; preservedTempDir=$tempDir
    }
    exit 1
}

Write-Status @{ stage='audio-store'; status='OK' }
$completedStages += 'audio-store'

# ── Stage: scheduler ──────────────────────────────────────────────────────────
Write-Status @{ stage='scheduler'; status='running' }

$schedulerScript = @'
import { createNodeScheduler } from './adapters/scheduler-node/dist/index.js';

let runCount = 0;
let errorCount = 0;

const scheduler = createNodeScheduler(
    async (kind, nowIso) => { runCount++; return { kind, nowIso }; },
    (err) => { errorCount++; console.error('Scheduler error:', err); }
);

// Test 1: Verify interface exists
if (typeof scheduler.schedule !== 'function') {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'no-schedule' }));
    process.exit(1);
}
if (typeof scheduler.close !== 'function') {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'no-close' }));
    process.exit(1);
}

// Test 2: Schedule with a cron expression that fires every minute
// Format: minute hour day-of-month month day-of-week
// "* * * * *" = every minute (only minute and hour vary, rest must be *)
await scheduler.schedule('pii_retention', '* * * * *');

// Test 3: Verify invalid job kind is rejected
try {
    await scheduler.schedule('invalid_job_kind', '* * * * *');
    console.log(JSON.stringify({ status: 'FAIL', reason: 'accepted-invalid-kind' }));
    process.exit(1);
} catch (e) {
    // Expected: unsupported_scheduled_job
}

// Test 4: Verify invalid cron is rejected  
try {
    await scheduler.schedule('pii_retention', 'not-a-cron');
    console.log(JSON.stringify({ status: 'FAIL', reason: 'accepted-invalid-cron' }));
    process.exit(1);
} catch (e) {
    // Expected: unsupported_cron_expression
}

scheduler.close();

console.log(JSON.stringify({ status: 'OK', hasInterface: true, errorCount }));
'@

$schedulerScriptPath = Join-Path $tempDir '_scheduler.mjs'
Set-Content -LiteralPath $schedulerScriptPath -Value $schedulerScript -Encoding UTF8

$schedulerResult = Invoke-NodeWithOutput -ArgumentList @($schedulerScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $schedulerScriptPath -Force -ErrorAction SilentlyContinue

if ($schedulerResult.ExitCode -ne 0) {
    $listing = Get-DirListing $tempDir
    Write-Status @{ 
        stage='scheduler'; status='FAIL'; reason='scheduler-script-failed';
        exitCode=$schedulerResult.ExitCode; stdout=$schedulerResult.Stdout; stderr=$schedulerResult.Stderr;
        tempDirListing=$listing; preservedTempDir=$tempDir
    }
    exit 1
}

Write-Status @{ stage='scheduler'; status='OK' }
$completedStages += 'scheduler'

# ── Stage: identity ───────────────────────────────────────────────────────────
Write-Status @{ stage='identity'; status='running' }

# Use compiled JavaScript and the new stableUserId config
$identityScript = @'
import { createLocalSingleIdentity, generateStableUserId } from './apps/local-service/dist/identity.js';

// Generate a stable user ID (in production this would be generated at install and stored in DPAPI)
const stableUserId = generateStableUserId();

const config = {
    stableUserId,
    orgId: 'test-org',
    roles: ['institution-admin', 'worker'],
};

const identity = createLocalSingleIdentity(config);

// Check the bearer token exists (memory-only, generated fresh each time)
if (!identity.bearer || identity.bearer.length < 32) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'no-bearer' }));
    process.exit(1);
}

// Check stableUserId matches what we provided
if (identity.stableUserId !== stableUserId) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'stableUserId-mismatch', expected: stableUserId, got: identity.stableUserId }));
    process.exit(1);
}

// Test resolve with correct bearer
const actor = await identity.resolve({ headers: { get: (name) => name === 'authorization' ? `Bearer ${identity.bearer}` : null } });
if (!actor || actor.userId !== identity.stableUserId) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'resolve-failed', actor, expected: identity.stableUserId }));
    process.exit(1);
}

// Test resolve with wrong bearer throws error
try {
    await identity.resolve({ headers: { get: (name) => name === 'authorization' ? 'Bearer wrong-token' : null } });
    console.log(JSON.stringify({ status: 'FAIL', reason: 'accepted-bad-bearer' }));
    process.exit(1);
} catch (e) {
    // Expected: ActorAuthenticationError
    if (!e.message.includes('invalid bearer')) {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'wrong-error', message: e.message }));
        process.exit(1);
    }
}

// Clean up
identity.close();

console.log(JSON.stringify({ status: 'OK', hasBearer: true, stableUserId }));
'@

$identityScriptPath = Join-Path $tempDir '_identity.mjs'
Set-Content -LiteralPath $identityScriptPath -Value $identityScript -Encoding UTF8

$identityResult = Invoke-NodeWithOutput -ArgumentList @($identityScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $identityScriptPath -Force -ErrorAction SilentlyContinue

if ($identityResult.ExitCode -ne 0) {
    $listing = Get-DirListing $tempDir
    Write-Status @{ 
        stage='identity'; status='FAIL'; reason='identity-script-failed';
        exitCode=$identityResult.ExitCode; stdout=$identityResult.Stdout; stderr=$identityResult.Stderr;
        tempDirListing=$listing; preservedTempDir=$tempDir
    }
    exit 1
}

Write-Status @{ stage='identity'; status='OK' }
$completedStages += 'identity'

# ── Stage: cleanup ────────────────────────────────────────────────────────────
Write-Status @{ stage='cleanup'; status='running' }

Set-Location $originalLocation

try {
    Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction Stop
    Write-Status @{ stage='cleanup'; status='OK' }
    $completedStages += 'cleanup'
} catch {
    Write-Status @{ stage='cleanup'; status='WARN'; reason='cleanup-failed'; error=$_.Exception.Message; tempDir=$tempDir }
    # Don't fail the whole run for cleanup issues
    $completedStages += 'cleanup'
}

# ── Final summary ─────────────────────────────────────────────────────────────
Write-Status @{ 
    stage='summary'; 
    status='OK'; 
    completedStages=$completedStages;
    totalStages=$completedStages.Count
}

exit 0
