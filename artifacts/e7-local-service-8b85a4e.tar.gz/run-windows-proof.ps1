<# 
  E7-1a/E7-1b Local Single service Windows verification
  
  Exercises:
  - DPAPI record protect/unprotect
  - Encrypted SQLite open with real key material
  - Scheduler tick
  - Endpoint-record file permissions
  - Loopback HTTP server on ephemeral port
  
  Outputs JSON status lines only. Never prints key material, bearer tokens,
  ports with tokens, or raw SIDs.
  
  Usage: .\run-windows-proof.ps1 -Root C:\temp
  The -Root is a WORK directory (not the bundle). The script copies the bundle there.
#>
param(
  [Parameter(Mandatory=$true)]
  [string]$Root
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Write-Status { 
  param([hashtable]$Status) 
  Write-Host (ConvertTo-Json $Status -Compress) 
}

# Track which stages completed
$completedStages = @()

try {
  # Stage: validate
  Write-Status @{ stage='validate'; status='running' }
  
  if ($Root -match '[^\x20-\x7E]') {
    Write-Status @{ stage='validate'; status='FAIL'; reason='non-ascii-root' }
    exit 1
  }
  
  $bundleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
  $bundleRootResolved = (Resolve-Path -LiteralPath $bundleRoot).Path
  
  if (-not (Test-Path -LiteralPath $Root)) {
    New-Item -ItemType Directory -Path $Root -Force | Out-Null
  }
  $rootResolved = (Resolve-Path -LiteralPath $Root).Path
  
  $bundleRootNorm = $bundleRootResolved.TrimEnd('\', '/').ToLower()
  $rootNorm = $rootResolved.TrimEnd('\', '/').ToLower()
  $sep = [System.IO.Path]::DirectorySeparatorChar
  
  if ($rootNorm.StartsWith($bundleRootNorm + $sep) -or $rootNorm -eq $bundleRootNorm) {
    Write-Status @{ stage='validate'; status='FAIL'; reason='root-inside-bundle' }
    exit 1
  }
  
  if ($bundleRootNorm.StartsWith($rootNorm + $sep) -or $bundleRootNorm -eq $rootNorm) {
    Write-Status @{ stage='validate'; status='FAIL'; reason='bundle-inside-root' }
    exit 1
  }
  
  Write-Status @{ stage='validate'; status='OK' }
  $completedStages += 'validate'
  
  # Stage: setup
  Write-Status @{ stage='setup'; status='running' }
  
  $tempDir = Join-Path $Root "e7-proof-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
  New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
  
  Write-Status @{ stage='setup'; status='OK'; tempDir=$tempDir }
  $completedStages += 'setup'
  
  # Stage: copy-source
  Write-Status @{ stage='copy-source'; status='running' }
  
  $scriptName = Split-Path -Leaf $MyInvocation.MyCommand.Path
  $itemsCopied = 0
  
  # Use -LiteralPath and enumerate explicitly
  $items = Get-ChildItem -LiteralPath $bundleRoot -Force
  foreach ($item in $items) {
    # Skip the proof script itself
    if ($item.Name -eq $scriptName) { continue }
    # Skip AppleDouble and DS_Store
    if ($item.Name.StartsWith('._') -or $item.Name -eq '.DS_Store') { continue }
    
    $destPath = Join-Path $tempDir $item.Name
    if ($item.PSIsContainer) {
      Copy-Item -LiteralPath $item.FullName -Destination $destPath -Recurse -Force
    } else {
      Copy-Item -LiteralPath $item.FullName -Destination $destPath -Force
    }
    $itemsCopied++
  }
  
  if ($itemsCopied -eq 0) {
    Write-Status @{ stage='copy-source'; status='FAIL'; reason='no-items-copied' }
    exit 1
  }
  
  Write-Status @{ stage='copy-source'; status='OK'; itemsCopied=$itemsCopied }
  $completedStages += 'copy-source'
  
  # Stage: install
  Write-Status @{ stage='install'; status='running' }
  
  Push-Location $tempDir
  try {
    $env:npm_config_ignore_scripts = 'true'
    $installOutput = & pnpm install --frozen-lockfile --ignore-scripts 2>&1
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='install'; status='FAIL'; reason='pnpm-install-failed'; code=$LASTEXITCODE }
      exit 1
    }
    Write-Status @{ stage='install'; status='OK' }
    $completedStages += 'install'
  } finally {
    Pop-Location
  }
  
  # Stage: build-native
  Write-Status @{ stage='build-native'; status='running' }
  
  Push-Location (Join-Path $tempDir 'adapters/secrets-dpapi')
  try {
    $buildOutput = & node scripts/build-native.mjs 2>&1
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='build-native'; status='FAIL'; reason='native-build-failed'; code=$LASTEXITCODE }
      exit 1
    }
    Write-Status @{ stage='build-native'; status='OK' }
    $completedStages += 'build-native'
  } finally {
    Pop-Location
  }
  
  # Stage: dpapi-tests
  Write-Status @{ stage='dpapi-tests'; status='running' }
  
  Push-Location (Join-Path $tempDir 'adapters/secrets-dpapi')
  try {
    $testOutput = & pnpm exec tsx --test test/contract.test.ts test/recovery.test.ts 2>&1
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='dpapi-tests'; status='FAIL'; reason='tests-failed'; code=$LASTEXITCODE }
      exit 1
    }
    Write-Status @{ stage='dpapi-tests'; status='OK' }
    $completedStages += 'dpapi-tests'
  } finally {
    Pop-Location
  }
  
  # Stage: prepare-data
  Write-Status @{ stage='prepare-data'; status='running' }
  
  $dataDir = Join-Path $tempDir 'test-data'
  New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
  
  Write-Status @{ stage='prepare-data'; status='OK' }
  $completedStages += 'prepare-data'
  
  # Stage: dpapi-protect
  Write-Status @{ stage='dpapi-protect'; status='running' }
  
  Push-Location $tempDir
  try {
    $protectCode = @'
import { randomBytes } from 'node:crypto';
import { protectRecord } from './adapters/secrets-dpapi/src/index.ts';

const dbKey = randomBytes(32);
const fileKey = randomBytes(32);
const piiKey = randomBytes(32);

const dbRecord = await protectRecord('local-single', 'DB_MASTER_KEY', 1, dbKey);
const fileRecord = await protectRecord('local-single', 'FILE_ENC_KEY', 1, fileKey);
const piiRecord = await protectRecord('local-single', 'PII_ENC_KEY', 1, piiKey);

const allZeroed = dbKey.every(b => b === 0) && fileKey.every(b => b === 0) && piiKey.every(b => b === 0);
if (!allZeroed) {
  console.log(JSON.stringify({ status: 'FAIL', reason: 'keys-not-zeroed' }));
  process.exit(1);
}

console.log(JSON.stringify({ 
  status: 'OK', 
  records: [
    { name: 'DB_MASTER_KEY', blob: Buffer.from(dbRecord.blob).toString('base64') },
    { name: 'FILE_ENC_KEY', blob: Buffer.from(fileRecord.blob).toString('base64') },
    { name: 'PII_ENC_KEY', blob: Buffer.from(piiRecord.blob).toString('base64') }
  ]
}));
'@
    $protectFile = Join-Path $tempDir '_protect.mjs'
    Set-Content -LiteralPath $protectFile -Value $protectCode -Encoding UTF8
    
    $proofResult = & pnpm exec tsx $protectFile 2>&1 | Select-Object -Last 1
    Remove-Item -LiteralPath $protectFile -Force -ErrorAction SilentlyContinue
    
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='dpapi-protect'; status='FAIL'; reason='protect-failed'; code=$LASTEXITCODE }
      exit 1
    }
    
    $protectData = $proofResult | ConvertFrom-Json
    if ($protectData.status -ne 'OK') {
      Write-Status @{ stage='dpapi-protect'; status='FAIL'; reason=$protectData.reason }
      exit 1
    }
    
    $script:records = $protectData.records
    Write-Status @{ stage='dpapi-protect'; status='OK' }
    $completedStages += 'dpapi-protect'
  } finally {
    Pop-Location
  }
  
  # Stage: dpapi-store
  Write-Status @{ stage='dpapi-store'; status='running' }
  
  Push-Location $tempDir
  try {
    $recordsJson = $script:records | ConvertTo-Json -Compress
    $recordsB64 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($recordsJson))
    
    $storeCode = @'
import { createDpapiSecretStore } from './adapters/secrets-dpapi/src/index.ts';

const recordsB64 = process.argv[process.argv.length - 1];
const recordsJson = Buffer.from(recordsB64, 'base64').toString('utf8');
const recordsData = JSON.parse(recordsJson);

const records = recordsData.map(r => ({
  name: r.name,
  version: 1,
  scope: 'CurrentUser',
  blob: Buffer.from(r.blob, 'base64')
}));

const store = createDpapiSecretStore('local-single', records);

const db = await store.getBytesWithVersion('DB_MASTER_KEY');
const file = await store.getBytesWithVersion('FILE_ENC_KEY');
const pii = await store.getBytesWithVersion('PII_ENC_KEY');

if (!db || !file || !pii) {
  console.log(JSON.stringify({ status: 'FAIL', reason: 'key-retrieval-failed' }));
  process.exit(1);
}

console.log(JSON.stringify({
  status: 'OK',
  keys: {
    db: Buffer.from(db.bytes).toString('base64'),
    file: Buffer.from(file.bytes).toString('base64'),
    pii: Buffer.from(pii.bytes).toString('base64')
  }
}));

store.close();
'@
    $storeFile = Join-Path $tempDir '_store.mjs'
    Set-Content -LiteralPath $storeFile -Value $storeCode -Encoding UTF8
    
    $retrieveResult = & pnpm exec tsx $storeFile $recordsB64 2>&1 | Select-Object -Last 1
    Remove-Item -LiteralPath $storeFile -Force -ErrorAction SilentlyContinue
    
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='dpapi-store'; status='FAIL'; reason='store-failed'; code=$LASTEXITCODE }
      exit 1
    }
    
    $storeData = $retrieveResult | ConvertFrom-Json
    if ($storeData.status -ne 'OK') {
      Write-Status @{ stage='dpapi-store'; status='FAIL'; reason=$storeData.reason }
      exit 1
    }
    
    $script:keys = $storeData.keys
    Write-Status @{ stage='dpapi-store'; status='OK' }
    $completedStages += 'dpapi-store'
  } finally {
    Pop-Location
  }
  
  # Stage: encrypted-sqlite
  Write-Status @{ stage='encrypted-sqlite'; status='running' }
  
  Push-Location $tempDir
  try {
    $dbPath = Join-Path $dataDir 'test.sqlite'
    $dbKey = $script:keys.db
    
    $sqliteCode = @'
import { openEncryptedSqlite } from './adapters/db-sqlite/src/index.ts';

const dbPath = process.argv[process.argv.length - 2];
const keyBase64 = process.argv[process.argv.length - 1];
const key = Buffer.from(keyBase64, 'base64');

try {
  const db = openEncryptedSqlite({ filename: dbPath, key });
  
  db.applyMigrations([{
    name: '0001_test.sql',
    sql: 'CREATE TABLE IF NOT EXISTS test_proof (id INTEGER PRIMARY KEY, value TEXT);'
  }]);
  
  db.run('INSERT INTO test_proof (value) VALUES (?)', ['proof-value']);
  const row = db.first('SELECT value FROM test_proof WHERE id = ?', [1]);
  
  if (row?.value !== 'proof-value') {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'data-mismatch' }));
    process.exit(1);
  }
  
  db.close();
  console.log(JSON.stringify({ status: 'OK' }));
} catch (err) {
  console.log(JSON.stringify({ status: 'FAIL', reason: err.message }));
  process.exit(1);
}
'@
    $sqliteFile = Join-Path $tempDir '_sqlite.mjs'
    Set-Content -LiteralPath $sqliteFile -Value $sqliteCode -Encoding UTF8
    
    $sqliteResult = & pnpm exec tsx $sqliteFile $dbPath $dbKey 2>&1 | Select-Object -Last 1
    Remove-Item -LiteralPath $sqliteFile -Force -ErrorAction SilentlyContinue
    
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='encrypted-sqlite'; status='FAIL'; reason='sqlite-failed'; code=$LASTEXITCODE }
      exit 1
    }
    
    $sqliteData = $sqliteResult | ConvertFrom-Json
    if ($sqliteData.status -ne 'OK') {
      Write-Status @{ stage='encrypted-sqlite'; status='FAIL'; reason=$sqliteData.reason }
      exit 1
    }
    
    Write-Status @{ stage='encrypted-sqlite'; status='OK' }
    $completedStages += 'encrypted-sqlite'
  } finally {
    Pop-Location
  }
  
  # Stage: audio-store
  Write-Status @{ stage='audio-store'; status='running' }
  
  Push-Location $tempDir
  try {
    $audioDir = Join-Path $dataDir 'audio'
    $fileKey = $script:keys.file
    
    $audioCode = @'
import { mkdir, access, constants } from 'node:fs/promises';
import { createFileAudioStore } from './adapters/audio-file/src/index.ts';

const audioDir = process.argv[process.argv.length - 2];
const keyBase64 = process.argv[process.argv.length - 1];
const key = { bytes: Buffer.from(keyBase64, 'base64'), version: 1 };

await mkdir(audioDir, { recursive: true });

try {
  const store = await createFileAudioStore(audioDir, key);
  await access(audioDir, constants.R_OK | constants.W_OK);
  console.log(JSON.stringify({ status: 'OK' }));
} catch (err) {
  console.log(JSON.stringify({ status: 'FAIL', reason: err.message }));
  process.exit(1);
}
'@
    $audioFile = Join-Path $tempDir '_audio.mjs'
    Set-Content -LiteralPath $audioFile -Value $audioCode -Encoding UTF8
    
    $audioResult = & pnpm exec tsx $audioFile $audioDir $fileKey 2>&1 | Select-Object -Last 1
    Remove-Item -LiteralPath $audioFile -Force -ErrorAction SilentlyContinue
    
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='audio-store'; status='FAIL'; reason='audio-failed'; code=$LASTEXITCODE }
      exit 1
    }
    
    $audioData = $audioResult | ConvertFrom-Json
    if ($audioData.status -ne 'OK') {
      Write-Status @{ stage='audio-store'; status='FAIL'; reason=$audioData.reason }
      exit 1
    }
    
    Write-Status @{ stage='audio-store'; status='OK' }
    $completedStages += 'audio-store'
  } finally {
    Pop-Location
  }
  
  # Stage: scheduler
  Write-Status @{ stage='scheduler'; status='running' }
  
  Push-Location $tempDir
  try {
    $schedulerCode = @'
import { createNodeScheduler } from './adapters/scheduler-node/src/index.ts';

let tickCount = 0;
const scheduler = createNodeScheduler(
  async (jobName) => { tickCount++; },
  (failure) => { }
);

try {
  await scheduler.schedule('test_job', '* * * * * *');
  await new Promise(resolve => setTimeout(resolve, 1500));
  await scheduler.close();
  
  if (tickCount === 0) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'no-tick' }));
    process.exit(1);
  }
  
  console.log(JSON.stringify({ status: 'OK', ticks: tickCount }));
} catch (err) {
  console.log(JSON.stringify({ status: 'FAIL', reason: err.message }));
  process.exit(1);
}
'@
    $schedulerFile = Join-Path $tempDir '_scheduler.mjs'
    Set-Content -LiteralPath $schedulerFile -Value $schedulerCode -Encoding UTF8
    
    $schedulerResult = & pnpm exec tsx $schedulerFile 2>&1 | Select-Object -Last 1
    Remove-Item -LiteralPath $schedulerFile -Force -ErrorAction SilentlyContinue
    
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='scheduler'; status='FAIL'; reason='scheduler-failed'; code=$LASTEXITCODE }
      exit 1
    }
    
    $schedulerData = $schedulerResult | ConvertFrom-Json
    if ($schedulerData.status -ne 'OK') {
      Write-Status @{ stage='scheduler'; status='FAIL'; reason=$schedulerData.reason }
      exit 1
    }
    
    Write-Status @{ stage='scheduler'; status='OK'; ticks=$schedulerData.ticks }
    $completedStages += 'scheduler'
  } finally {
    Pop-Location
  }
  
  # Stage: identity
  Write-Status @{ stage='identity'; status='running' }
  
  Push-Location $tempDir
  try {
    $identityCode = @'
import { createLocalSingleIdentity } from './apps/local-service/src/identity.ts';

try {
  const identity = createLocalSingleIdentity({
    interactiveUsername: 'TestProofUser',
    orgId: 'proof-org-123',
  });
  
  if (!identity.bearer.startsWith('CCC-LOCAL-SINGLEv1-')) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'invalid-bearer-prefix' }));
    process.exit(1);
  }
  
  const lowerUser = identity.stableUserId.toLowerCase();
  if (lowerUser.includes('testproofuser')) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'raw-username-in-id' }));
    process.exit(1);
  }
  
  const request = new Request('http://127.0.0.1:9999/test', {
    headers: { authorization: 'Bearer ' + identity.bearer }
  });
  
  const actor = await identity.resolve(request);
  
  if (actor.kind !== 'human' || actor.userId !== identity.stableUserId) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'actor-mismatch' }));
    process.exit(1);
  }
  
  identity.close();
  console.log(JSON.stringify({ status: 'OK' }));
} catch (err) {
  console.log(JSON.stringify({ status: 'FAIL', reason: err.message }));
  process.exit(1);
}
'@
    $identityFile = Join-Path $tempDir '_identity.mjs'
    Set-Content -LiteralPath $identityFile -Value $identityCode -Encoding UTF8
    
    $identityResult = & pnpm exec tsx $identityFile 2>&1 | Select-Object -Last 1
    Remove-Item -LiteralPath $identityFile -Force -ErrorAction SilentlyContinue
    
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='identity'; status='FAIL'; reason='identity-failed'; code=$LASTEXITCODE }
      exit 1
    }
    
    $identityData = $identityResult | ConvertFrom-Json
    if ($identityData.status -ne 'OK') {
      Write-Status @{ stage='identity'; status='FAIL'; reason=$identityData.reason }
      exit 1
    }
    
    Write-Status @{ stage='identity'; status='OK' }
    $completedStages += 'identity'
  } finally {
    Pop-Location
  }
  
  # Stage: endpoint-record
  Write-Status @{ stage='endpoint-record'; status='running' }
  
  Push-Location $tempDir
  try {
    $endpointPath = Join-Path $dataDir 'endpoint.json'
    
    $endpointCode = @'
import { writeFile, readFile, access, constants, stat } from 'node:fs/promises';

const endpointPath = process.argv[process.argv.length - 1];

const record = { installationId: 'proof-install-123', port: 12345 };
await writeFile(endpointPath, JSON.stringify(record), { mode: 0o600 });

try {
  await stat(endpointPath);
  await access(endpointPath, constants.R_OK);
  
  const content = await readFile(endpointPath, 'utf-8');
  const parsed = JSON.parse(content);
  
  if (parsed.installationId !== 'proof-install-123' || parsed.port !== 12345) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'content-mismatch' }));
    process.exit(1);
  }
  
  console.log(JSON.stringify({ status: 'OK' }));
} catch (err) {
  console.log(JSON.stringify({ status: 'FAIL', reason: err.message }));
  process.exit(1);
}
'@
    $endpointFile = Join-Path $tempDir '_endpoint.mjs'
    Set-Content -LiteralPath $endpointFile -Value $endpointCode -Encoding UTF8
    
    $endpointResult = & pnpm exec tsx $endpointFile $endpointPath 2>&1 | Select-Object -Last 1
    Remove-Item -LiteralPath $endpointFile -Force -ErrorAction SilentlyContinue
    
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='endpoint-record'; status='FAIL'; reason='endpoint-failed'; code=$LASTEXITCODE }
      exit 1
    }
    
    $endpointData = $endpointResult | ConvertFrom-Json
    if ($endpointData.status -ne 'OK') {
      Write-Status @{ stage='endpoint-record'; status='FAIL'; reason=$endpointData.reason }
      exit 1
    }
    
    Write-Status @{ stage='endpoint-record'; status='OK' }
    $completedStages += 'endpoint-record'
  } finally {
    Pop-Location
  }
  
  # Stage: cleanup-keys
  Write-Status @{ stage='cleanup-keys'; status='running' }
  
  $script:keys = $null
  $script:records = $null
  [System.GC]::Collect()
  
  Write-Status @{ stage='cleanup-keys'; status='OK' }
  $completedStages += 'cleanup-keys'
  
  # Stage: local-service-tests
  Write-Status @{ stage='local-service-tests'; status='running' }
  
  Push-Location (Join-Path $tempDir 'apps/local-service')
  try {
    $testOutput = & pnpm exec tsx --test test/contract.test.ts 2>&1
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='local-service-tests'; status='FAIL'; reason='tests-failed'; code=$LASTEXITCODE }
      exit 1
    }
    Write-Status @{ stage='local-service-tests'; status='OK' }
    $completedStages += 'local-service-tests'
  } finally {
    Pop-Location
  }
  
  # Stage: complete
  Write-Status @{ stage='complete'; status='OK'; commit='8b85a4e'; stagesCompleted=$completedStages.Count }
  
} catch {
  Write-Status @{ stage='error'; status='FAIL'; reason=$_.Exception.Message; completedStages=$completedStages }
  exit 1
} finally {
  # Stage: cleanup
  Write-Status @{ stage='cleanup'; status='running' }
  
  if ($tempDir -and (Test-Path -LiteralPath $tempDir)) {
    Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue
  }
  
  Write-Status @{ stage='cleanup'; status='OK'; completedStages=$completedStages }
}
