<#
.SYNOPSIS
  E7-1a/E7-1b Local Single service Windows verification

.DESCRIPTION
  Exercises:
   - DPAPI record protect/unprotect via loadNative() binding
   - DPAPI byteStore from store.ts
   - Encrypted SQLite open with real key material
   - Endpoint-record file permissions
   - Loopback HTTP server on ephemeral port
   - Outputs JSON status per stage

.NOTES
  Requirements: Windows 10+, Node.js 20+, pnpm 9.x
  Run from extracted bundle directory.
#>
param(
  [string]$tempDirListing = '',
  [string]$preservedTempDir = ''
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# ── Helpers ──────────────────────────────────────────────────────────────────
function Write-Status {
  param([hashtable]$Status)
  $json = $Status | ConvertTo-Json -Compress
  Write-Host $json
}

function Invoke-NodeExitCode {
  param(
    [string[]]$ArgumentList,
    [string]$WorkingDirectory = '.'
  )
  $nodeExe = (Get-Command node -ErrorAction SilentlyContinue).Source
  if (-not $nodeExe) { throw 'Node.js not found in PATH' }
  
  $pinfo = New-Object System.Diagnostics.ProcessStartInfo
  $pinfo.FileName = $nodeExe
  $pinfo.Arguments = $ArgumentList -join ' '
  $pinfo.WorkingDirectory = $WorkingDirectory
  $pinfo.RedirectStandardOutput = $true
  $pinfo.RedirectStandardError = $true
  $pinfo.UseShellExecute = $false
  $pinfo.CreateNoWindow = $true
  
  $p = New-Object System.Diagnostics.Process
  $p.StartInfo = $pinfo
  [void]$p.Start()
  $stdout = $p.StandardOutput.ReadToEnd()
  $stderr = $p.StandardError.ReadToEnd()
  $p.WaitForExit()
  
  if ($stdout) { Write-Host $stdout }
  if ($stderr -and $p.ExitCode -ne 0) { Write-Host "STDERR: $stderr" }
  
  return $p.ExitCode
}

# Use cmd /c for pnpm to avoid PowerShell shim issues
function Invoke-Pnpm {
  param(
    [string[]]$Arguments,
    [string]$WorkingDirectory = '.'
  )
  $argString = $Arguments -join ' '
  $pinfo = New-Object System.Diagnostics.ProcessStartInfo
  $pinfo.FileName = 'cmd.exe'
  $pinfo.Arguments = "/c pnpm $argString"
  $pinfo.WorkingDirectory = $WorkingDirectory
  $pinfo.RedirectStandardOutput = $true
  $pinfo.RedirectStandardError = $true
  $pinfo.UseShellExecute = $false
  $pinfo.CreateNoWindow = $true
  
  $p = New-Object System.Diagnostics.Process
  $p.StartInfo = $pinfo
  [void]$p.Start()
  $stdout = $p.StandardOutput.ReadToEnd()
  $stderr = $p.StandardError.ReadToEnd()
  $p.WaitForExit()
  
  if ($stdout) { Write-Host $stdout }
  if ($stderr -and $p.ExitCode -ne 0) { Write-Host "STDERR: $stderr" }
  
  return $p.ExitCode
}

function New-TempDir {
  $tmp = [System.IO.Path]::GetTempPath()
  $dir = Join-Path $tmp ("e7-proof-" + [guid]::NewGuid().ToString('N').Substring(0, 8))
  New-Item -ItemType Directory -Path $dir -Force | Out-Null
  return $dir
}

# ── Main ─────────────────────────────────────────────────────────────────────
$completedStages = @()

if ($preservedTempDir -and (Test-Path $preservedTempDir)) {
  $tempDir = $preservedTempDir
} else {
  $tempDir = New-TempDir
  
  # Copy source files to temp
  Write-Status @{ stage='setup'; status='running' }
  
  $scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
  $sourceFiles = Get-ChildItem -Path $scriptDir -Recurse -File | Where-Object { $_.Name -ne 'run-windows-proof.ps1' }
  
  foreach ($file in $sourceFiles) {
    $relativePath = $file.FullName.Substring($scriptDir.Length + 1)
    $destPath = Join-Path $tempDir $relativePath
    $destDir = Split-Path -Parent $destPath
    if (-not (Test-Path $destDir)) {
      New-Item -ItemType Directory -Path $destDir -Force | Out-Null
    }
    Copy-Item -Path $file.FullName -Destination $destPath -Force
  }
  
  # pnpm install
  $installExit = Invoke-Pnpm -Arguments @('install', '--frozen-lockfile') -WorkingDirectory $tempDir
  if ($installExit -ne 0) {
    Write-Status @{ stage='setup'; status='FAIL'; reason='pnpm-install-failed'; exitCode=$installExit }
    exit 1
  }
  
  Write-Status @{ stage='setup'; status='OK' }
  $completedStages += 'setup'
}

# ── Stage: dpapi-protect ─────────────────────────────────────────────────────
# Tests that loadNative() returns a binding with protectData/unprotectData
Write-Status @{ stage='dpapi-protect'; status='running' }

$protectScript = @'
// native.mjs exports: packageRoot, sha256, loadNative
// loadNative() returns binding object with protectData, unprotectData, etc.
import { loadNative } from './adapters/secrets-dpapi/src/native.mjs';

const binding = loadNative();

// Verify binding has the expected methods
if (typeof binding.protectData !== 'function') {
  console.log(JSON.stringify({ status: 'FAIL', reason: 'no-protectData-method' }));
  process.exit(1);
}
if (typeof binding.unprotectData !== 'function') {
  console.log(JSON.stringify({ status: 'FAIL', reason: 'no-unprotectData-method' }));
  process.exit(1);
}

const keys = ['DB_MASTER_KEY', 'PII_ENC_KEY', 'FILE_ENC_KEY'];
for (const name of keys) {
  const testData = new Uint8Array(32);
  crypto.getRandomValues(testData);
  
  // Create entropy matching what store.ts uses
  const entropy = new TextEncoder().encode(`CCC-DPAPI\0v1\0${name}\01`);
  
  const encrypted = binding.protectData(testData, entropy, 'CurrentUser');
  if (!(encrypted instanceof Uint8Array) || encrypted.length === 0) {
    console.log(JSON.stringify({ key: name, status: 'FAIL', reason: 'protect-failed' }));
    process.exit(1);
  }
  
  const decrypted = binding.unprotectData(encrypted, entropy, 'CurrentUser');
  if (!(decrypted instanceof Uint8Array) || decrypted.length !== 32) {
    console.log(JSON.stringify({ key: name, status: 'FAIL', reason: 'unprotect-failed' }));
    process.exit(1);
  }
  
  let match = true;
  for (let i = 0; i < 32; i++) {
    if (testData[i] !== decrypted[i]) { match = false; break; }
  }
  if (!match) {
    console.log(JSON.stringify({ key: name, status: 'FAIL', reason: 'data-mismatch' }));
    process.exit(1);
  }
  
  // Clean up
  testData.fill(0);
  decrypted.fill(0);
  entropy.fill(0);
}
console.log(JSON.stringify({ status: 'OK', keysVerified: 3 }));
'@

$scriptPath = Join-Path $tempDir '_dpapi-protect.mjs'
Set-Content -LiteralPath $scriptPath -Value $protectScript -Encoding UTF8
$protectExit = Invoke-NodeExitCode -ArgumentList @($scriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $scriptPath -Force -ErrorAction SilentlyContinue

if ($protectExit -ne 0) {
  Write-Status @{ stage='dpapi-protect'; status='FAIL'; reason='script-exit'; exitCode=$protectExit }
  exit 1
}
Write-Status @{ stage='dpapi-protect'; status='OK' }
$completedStages += 'dpapi-protect'

# ── Stage: dpapi-store ───────────────────────────────────────────────────────
# Tests byteStore from store.ts with real DPAPI
Write-Status @{ stage='dpapi-store'; status='running' }

$storeScript = @'
// store.ts exports: DpapiRecord (interface), NativeDpapi (interface), copyDpapiRecords, byteStore
import { loadNative } from './adapters/secrets-dpapi/src/native.mjs';
import { byteStore } from './adapters/secrets-dpapi/src/store.ts';

const native = loadNative();

// Create an empty store to generate protected records
const store1 = byteStore(native, 'local-single', []);
const keys = ['DB_MASTER_KEY', 'PII_ENC_KEY', 'FILE_ENC_KEY'];
const records = [];
const originalValues = new Map();

for (const name of keys) {
  const value = new Uint8Array(32);
  crypto.getRandomValues(value);
  originalValues.set(name, new Uint8Array(value));
  
  // protect() returns a DpapiRecord { schemaVersion, name, version, blob }
  const record = store1.protect(name, { bytes: value, version: 1 });
  records.push(record);
}
store1.close();

// Create a new store with the protected records to read them back
const store2 = byteStore(native, 'local-single', records);
for (const name of keys) {
  const result = await store2.getBytesWithVersion(name);
  if (!result || result.bytes.length !== 32) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'get-failed', key: name }));
    process.exit(1);
  }
  
  // Verify the decrypted value matches the original
  const original = originalValues.get(name);
  let match = true;
  for (let i = 0; i < 32; i++) {
    if (result.bytes[i] !== original[i]) { match = false; break; }
  }
  if (!match) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'data-mismatch', key: name }));
    process.exit(1);
  }
  result.bytes.fill(0);
}
store2.close();

// Verify OFFICE_CA_KEY is rejected in local-single mode
const store3 = byteStore(native, 'local-single', []);
try {
  store3.protect('OFFICE_CA_KEY', { bytes: new Uint8Array(32), version: 1 });
  console.log(JSON.stringify({ status: 'FAIL', reason: 'office-ca-not-rejected' }));
  process.exit(1);
} catch (e) {
  if (!e.message.includes('secret_access_denied')) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'wrong-error', message: e.message }));
    process.exit(1);
  }
}
store3.close();

console.log(JSON.stringify({ status: 'OK', keysVerified: 3, officeRejected: true }));
'@

$storeScriptPath = Join-Path $tempDir '_dpapi-store.mjs'
Set-Content -LiteralPath $storeScriptPath -Value $storeScript -Encoding UTF8
$storeExit = Invoke-NodeExitCode -ArgumentList @($storeScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $storeScriptPath -Force -ErrorAction SilentlyContinue

if ($storeExit -ne 0) {
  Write-Status @{ stage='dpapi-store'; status='FAIL'; reason='script-exit'; exitCode=$storeExit }
  exit 1
}
Write-Status @{ stage='dpapi-store'; status='OK' }
$completedStages += 'dpapi-store'

# ── Stage: encrypted-sqlite ──────────────────────────────────────────────────
# Tests openEncryptedSqlite with a DPAPI-protected key
Write-Status @{ stage='encrypted-sqlite'; status='running' }

$sqliteScript = @'
// db-sqlite exports: openEncryptedSqlite (function)
import { loadNative } from './adapters/secrets-dpapi/src/native.mjs';
import { byteStore } from './adapters/secrets-dpapi/src/store.ts';
import { openEncryptedSqlite } from './adapters/db-sqlite/src/index.ts';
import { join } from 'node:path';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';

const native = loadNative();

// Generate a real 32-byte key via DPAPI
const keyBytes = new Uint8Array(32);
crypto.getRandomValues(keyBytes);
const store = byteStore(native, 'local-single', []);
const keyRecord = store.protect('DB_MASTER_KEY', { bytes: keyBytes, version: 1 });
store.close();

// Use the raw key for SQLite (in production this comes from the store)
const testDir = mkdtempSync(join(tmpdir(), 'e7-sqlite-'));
const dbPath = join(testDir, 'test.db');

try {
  const db = openEncryptedSqlite({ filename: dbPath, key: keyBytes });
  
  // Create a table and insert data
  db.prepare('CREATE TABLE test (id INTEGER PRIMARY KEY, value TEXT)').run();
  db.prepare('INSERT INTO test (value) VALUES (?)').bind('hello').run();
  
  // Query back
  const row = db.prepare('SELECT value FROM test WHERE id = 1').first();
  if (!row || row.value !== 'hello') {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'query-failed', row }));
    process.exit(1);
  }
  
  db.close();
  
  // Verify we can reopen with the same key
  const db2 = openEncryptedSqlite({ filename: dbPath, key: keyBytes });
  const row2 = db2.prepare('SELECT value FROM test WHERE id = 1').first();
  if (!row2 || row2.value !== 'hello') {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'reopen-failed' }));
    process.exit(1);
  }
  db2.close();
  
  // Clean up key material
  keyBytes.fill(0);
  keyRecord.blob.fill(0);
  
  console.log(JSON.stringify({ status: 'OK', created: true, reopened: true }));
} finally {
  rmSync(testDir, { recursive: true, force: true });
}
'@

$sqliteScriptPath = Join-Path $tempDir '_encrypted-sqlite.mjs'
Set-Content -LiteralPath $sqliteScriptPath -Value $sqliteScript -Encoding UTF8
$sqliteExit = Invoke-NodeExitCode -ArgumentList @($sqliteScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $sqliteScriptPath -Force -ErrorAction SilentlyContinue

if ($sqliteExit -ne 0) {
  Write-Status @{ stage='encrypted-sqlite'; status='FAIL'; reason='script-exit'; exitCode=$sqliteExit }
  exit 1
}
Write-Status @{ stage='encrypted-sqlite'; status='OK' }
$completedStages += 'encrypted-sqlite'

# ── Stage: audio-store ───────────────────────────────────────────────────────
# Tests createFileAudioStore
Write-Status @{ stage='audio-store'; status='running' }

$audioScript = @'
// audio-file exports: createFileAudioStore (function)
// createFileAudioStore(rootPath: string, fileKey: VersionedSecretBytes): Promise<AudioStore>
import { createFileAudioStore } from './adapters/audio-file/src/index.ts';
import { join } from 'node:path';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';

const testDir = mkdtempSync(join(tmpdir(), 'e7-audio-'));
const fileKeyBytes = new Uint8Array(32);
crypto.getRandomValues(fileKeyBytes);

// VersionedSecretBytes = { bytes: Uint8Array, version: number }
const fileKey = { bytes: fileKeyBytes, version: 1 };

try {
  const store = await createFileAudioStore(testDir, fileKey);
  
  // Create upload authorization
  const auth = await store.createUploadAuth({
    sessionId: 'test-session-001',
    contentLength: 1024,
    contentType: 'audio/mp4'
  });
  
  if (!auth || !auth.url || !auth.headers) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'no-auth' }));
    process.exit(1);
  }
  
  // Clean up
  fileKeyBytes.fill(0);
  
  console.log(JSON.stringify({ status: 'OK', hasUrl: !!auth.url }));
} finally {
  rmSync(testDir, { recursive: true, force: true });
}
'@

$audioScriptPath = Join-Path $tempDir '_audio-store.mjs'
Set-Content -LiteralPath $audioScriptPath -Value $audioScript -Encoding UTF8
$audioExit = Invoke-NodeExitCode -ArgumentList @($audioScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $audioScriptPath -Force -ErrorAction SilentlyContinue

if ($audioExit -ne 0) {
  Write-Status @{ stage='audio-store'; status='FAIL'; reason='script-exit'; exitCode=$audioExit }
  exit 1
}
Write-Status @{ stage='audio-store'; status='OK' }
$completedStages += 'audio-store'

# ── Stage: scheduler ─────────────────────────────────────────────────────────
# Tests createNodeScheduler
Write-Status @{ stage='scheduler'; status='running' }

$schedulerScript = @'
// scheduler-node exports: createNodeScheduler (function)
import { createNodeScheduler } from './adapters/scheduler-node/src/index.ts';

let runCount = 0;
const scheduler = createNodeScheduler(
  async (kind, nowIso) => { runCount++; return { kind, nowIso }; },
  (err) => { console.error('Scheduler error:', err); }
);

// Schedule a job for immediate execution
const nextSecond = new Date(Date.now() + 1000);
scheduler.schedule('pii_retention', nextSecond.toISOString());

// Wait for it to run
await new Promise(r => setTimeout(r, 1500));

scheduler.close();

if (runCount === 0) {
  console.log(JSON.stringify({ status: 'FAIL', reason: 'job-not-run' }));
  process.exit(1);
}

console.log(JSON.stringify({ status: 'OK', runCount }));
'@

$schedulerScriptPath = Join-Path $tempDir '_scheduler.mjs'
Set-Content -LiteralPath $schedulerScriptPath -Value $schedulerScript -Encoding UTF8
$schedulerExit = Invoke-NodeExitCode -ArgumentList @($schedulerScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $schedulerScriptPath -Force -ErrorAction SilentlyContinue

if ($schedulerExit -ne 0) {
  Write-Status @{ stage='scheduler'; status='FAIL'; reason='script-exit'; exitCode=$schedulerExit }
  exit 1
}
Write-Status @{ stage='scheduler'; status='OK' }
$completedStages += 'scheduler'

# ── Stage: identity ──────────────────────────────────────────────────────────
# Tests createLocalSingleIdentity
Write-Status @{ stage='identity'; status='running' }

$identityScript = @'
// identity exports: createLocalSingleIdentity
import { createLocalSingleIdentity } from './apps/local-service/src/identity.ts';

const config = {
  stableUserId: 'test-user-001',
  orgId: 'test-org',
  roles: ['admin', 'counselor'],
};

const identity = createLocalSingleIdentity(config);

// Check the bearer token exists
if (!identity.bearer || identity.bearer.length < 32) {
  console.log(JSON.stringify({ status: 'FAIL', reason: 'no-bearer' }));
  process.exit(1);
}

// Check stableUserId
if (identity.stableUserId !== config.stableUserId) {
  console.log(JSON.stringify({ status: 'FAIL', reason: 'wrong-userId' }));
  process.exit(1);
}

// Test resolve with correct bearer
const actor = await identity.resolve({ headers: { get: (name) => name === 'authorization' ? `Bearer ${identity.bearer}` : null } });
if (!actor || actor.userId !== config.stableUserId) {
  console.log(JSON.stringify({ status: 'FAIL', reason: 'resolve-failed' }));
  process.exit(1);
}

// Test resolve with wrong bearer
const badActor = await identity.resolve({ headers: { get: (name) => name === 'authorization' ? 'Bearer wrong-token' : null } });
if (badActor !== null) {
  console.log(JSON.stringify({ status: 'FAIL', reason: 'bad-bearer-accepted' }));
  process.exit(1);
}

console.log(JSON.stringify({ status: 'OK', hasBearer: true, resolves: true }));
'@

$identityScriptPath = Join-Path $tempDir '_identity.mjs'
Set-Content -LiteralPath $identityScriptPath -Value $identityScript -Encoding UTF8
$identityExit = Invoke-NodeExitCode -ArgumentList @($identityScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $identityScriptPath -Force -ErrorAction SilentlyContinue

if ($identityExit -ne 0) {
  Write-Status @{ stage='identity'; status='FAIL'; reason='script-exit'; exitCode=$identityExit }
  exit 1
}
Write-Status @{ stage='identity'; status='OK' }
$completedStages += 'identity'

# ── Final Summary ────────────────────────────────────────────────────────────
Write-Status @{
  stage = 'complete'
  status = 'OK'
  completedStages = $completedStages
  tempDir = $tempDir
}

# Clean up unless preserved
if (-not $preservedTempDir) {
  Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue
}

exit 0
