$ErrorActionPreference = 'Stop'
if ($env:OS -ne 'Windows_NT' -or $PSScriptRoot -match '[^\x00-\x7F]') { throw 'windows_ascii_directory_required' }
function Invoke-Checked {
  param([string]$Exe, [string[]]$Arguments)
  & $Exe @Arguments
  if ($LASTEXITCODE -ne 0) { throw 'dpapi_source_proof_failed' }
}
Push-Location $PSScriptRoot
try {
  $nodeVersion = & node.exe --version
  if ($LASTEXITCODE -ne 0 -or $nodeVersion -ne 'v24.19.0') { throw 'node_24_19_0_required_for_this_proof' }
  $pnpmVersion = & pnpm.cmd --version
  if ($LASTEXITCODE -ne 0 -or $pnpmVersion -ne '11.5.3') { throw 'pnpm_11_5_3_required' }
  if (Test-Path 'adapters/secrets-dpapi/native-build') { throw 'fresh_extraction_required' }
  Invoke-Checked 'pnpm.cmd' @('install', '--frozen-lockfile', '--ignore-scripts')
  Invoke-Checked 'node.exe' @('adapters/secrets-dpapi/scripts/windows-smoke.mjs', '--expect-unbuilt')
  Invoke-Checked 'pnpm.cmd' @('--filter', '@ccc/secrets-dpapi', 'build:native')
  Invoke-Checked 'pnpm.cmd' @('--filter', '@ccc/secrets-dpapi', 'test')
  Invoke-Checked 'node.exe' @('adapters/secrets-dpapi/scripts/windows-smoke.mjs')
} finally {
  Pop-Location
}
