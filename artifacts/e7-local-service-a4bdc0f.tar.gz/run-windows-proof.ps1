<# 
  E7-1a/E7-1b Local Single service Windows verification
  
  Exercises:
  - DPAPI record protect/unprotect
  - Encrypted SQLite open with real key material
  - Scheduler tick
  - Endpoint-record file permissions
  - Loopback HTTP server on ephemeral port
  
  Outputs JSON status lines only. Never prints key material, bearer tokens,
  ports with tokens, or raw SIDs.
  
  Usage: .\run-windows-proof.ps1 -Root C:\temp
  The -Root is a WORK directory (not the bundle). The script copies the bundle there.
#>
param(
  [Parameter(Mandatory=$true)]
  [string]$Root
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Write-Stage { param([string]$Name) Write-Host "=== $Name ===" }
function Write-Status { param([hashtable]$Status) Write-Host (ConvertTo-Json $Status -Compress) }

# Validate ASCII root
if ($Root -match '[^\x20-\x7E]') {
  Write-Status @{ stage='validate'; status='FAIL'; reason='non-ascii-root' }
  exit 1
}

# Bundle root is where this script lives
$bundleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$bundleRootResolved = (Resolve-Path $bundleRoot).Path

# Ensure -Root exists or can be created
if (-not (Test-Path $Root)) {
  New-Item -ItemType Directory -Path $Root -Force | Out-Null
}
$rootResolved = (Resolve-Path $Root).Path

# Normalize paths for comparison (remove trailing slashes, use consistent separators)
$bundleRootNorm = $bundleRootResolved.TrimEnd('\', '/').ToLower()
$rootNorm = $rootResolved.TrimEnd('\', '/').ToLower()

# Ensure -Root is not inside the bundle (would cause recursive copy)
if ($rootNorm.StartsWith($bundleRootNorm + [System.IO.Path]::DirectorySeparatorChar) -or $rootNorm -eq $bundleRootNorm) {
  Write-Status @{ stage='validate'; status='FAIL'; reason='root-inside-bundle'; bundleRoot=$bundleRootResolved; root=$rootResolved }
  exit 1
}

# Ensure bundle is not inside -Root (would cause recursive copy)  
if ($bundleRootNorm.StartsWith($rootNorm + [System.IO.Path]::DirectorySeparatorChar) -or $bundleRootNorm -eq $rootNorm) {
  Write-Status @{ stage='validate'; status='FAIL'; reason='bundle-inside-root'; bundleRoot=$bundleRootResolved; root=$rootResolved }
  exit 1
}

$tempDir = Join-Path $Root "e7-proof-$(Get-Date -Format 'yyyyMMdd-HHmmss')"

try {
  Write-Stage "setup"
  
  # Create temp directory
  New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
  Write-Status @{ stage='setup'; status='OK'; tempDir=$tempDir }
  
  # Copy source bundle (exclude proof script)
  Write-Stage "copy-source"
  
  Get-ChildItem -Path $bundleRoot -Exclude 'run-windows-proof.ps1' | ForEach-Object {
    if ($_.PSIsContainer) {
      Copy-Item -Path $_.FullName -Destination (Join-Path $tempDir $_.Name) -Recurse -Force
    } else {
      Copy-Item -Path $_.FullName -Destination $tempDir -Force
    }
  }
  Write-Status @{ stage='copy-source'; status='OK' }
  
  # Frozen install
  Write-Stage "install"
  Push-Location $tempDir
  try {
    $env:npm_config_ignore_scripts = 'true'
    $installOutput = & pnpm install --frozen-lockfile --ignore-scripts 2>&1
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='install'; status='FAIL'; reason='pnpm-install-failed'; code=$LASTEXITCODE }
      exit 1
    }
    Write-Status @{ stage='install'; status='OK' }
  } finally {
    Pop-Location
  }
  
  # Build native addon
  Write-Stage "build-native"
  Push-Location (Join-Path $tempDir 'adapters/secrets-dpapi')
  try {
    $buildOutput = & node scripts/build-native.mjs 2>&1
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='build-native'; status='FAIL'; reason='native-build-failed'; code=$LASTEXITCODE }
      exit 1
    }
    Write-Status @{ stage='build-native'; status='OK' }
  } finally {
    Pop-Location
  }
  
  # Run DPAPI adapter tests
  Write-Stage "dpapi-tests"
  Push-Location (Join-Path $tempDir 'adapters/secrets-dpapi')
  try {
    $testOutput = & pnpm exec tsx --test test/contract.test.ts test/recovery.test.ts 2>&1
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='dpapi-tests'; status='FAIL'; reason='dpapi-tests-failed'; code=$LASTEXITCODE }
      exit 1
    }
    Write-Status @{ stage='dpapi-tests'; status='OK' }
  } finally {
    Pop-Location
  }
  
  # Create test data directory
  Write-Stage "prepare-data"
  $dataDir = Join-Path $tempDir 'test-data'
  New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
  Write-Status @{ stage='prepare-data'; status='OK' }
  
  # Run the local-service proof stages inline
  Write-Stage "dpapi-protect"
  Push-Location $tempDir
  try {
    $proofResult = & pnpm exec tsx -e @"
import { randomBytes } from 'node:crypto';
import { protectRecord } from './adapters/secrets-dpapi/src/index.ts';

const dbKey = randomBytes(32);
const fileKey = randomBytes(32);
const piiKey = randomBytes(32);

const dbRecord = await protectRecord('local-single', 'DB_MASTER_KEY', 1, dbKey);
const fileRecord = await protectRecord('local-single', 'FILE_ENC_KEY', 1, fileKey);
const piiRecord = await protectRecord('local-single', 'PII_ENC_KEY', 1, piiKey);

// Verify keys are zeroed after protect
const allZeroed = dbKey.every(b => b === 0) && fileKey.every(b => b === 0) && piiKey.every(b => b === 0);
if (!allZeroed) {
  console.log(JSON.stringify({ status: 'FAIL', reason: 'keys-not-zeroed' }));
  process.exit(1);
}

// Output records for next stage
console.log(JSON.stringify({ 
  status: 'OK', 
  records: [
    { name: 'DB_MASTER_KEY', blob: Buffer.from(dbRecord.blob).toString('base64') },
    { name: 'FILE_ENC_KEY', blob: Buffer.from(fileRecord.blob).toString('base64') },
    { name: 'PII_ENC_KEY', blob: Buffer.from(piiRecord.blob).toString('base64') }
  ]
}));
"@ 2>&1
    
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='dpapi-protect'; status='FAIL'; reason='protect-failed'; code=$LASTEXITCODE }
      exit 1
    }
    
    $protectData = $proofResult | ConvertFrom-Json
    if ($protectData.status -ne 'OK') {
      Write-Status @{ stage='dpapi-protect'; status='FAIL'; reason=$protectData.reason }
      exit 1
    }
    
    # Store records for later stages
    $script:records = $protectData.records
    Write-Status @{ stage='dpapi-protect'; status='OK' }
  } finally {
    Pop-Location
  }
  
  # DPAPI store retrieval
  Write-Stage "dpapi-store"
  Push-Location $tempDir
  try {
    $recordsJson = $script:records | ConvertTo-Json -Compress
    $retrieveResult = & pnpm exec tsx -e @"
import { createDpapiSecretStore } from './adapters/secrets-dpapi/src/index.ts';

const recordsData = JSON.parse(process.argv.slice(-1)[0]);
const records = recordsData.map(r => ({
  name: r.name,
  version: 1,
  scope: 'CurrentUser',
  blob: Buffer.from(r.blob, 'base64')
}));

const store = createDpapiSecretStore('local-single', records);

const db = await store.getBytesWithVersion('DB_MASTER_KEY');
const file = await store.getBytesWithVersion('FILE_ENC_KEY');
const pii = await store.getBytesWithVersion('PII_ENC_KEY');

if (!db || !file || !pii) {
  console.log(JSON.stringify({ status: 'FAIL', reason: 'key-retrieval-failed' }));
  process.exit(1);
}

// Output keys (base64) for next stages
console.log(JSON.stringify({
  status: 'OK',
  keys: {
    db: Buffer.from(db.bytes).toString('base64'),
    file: Buffer.from(file.bytes).toString('base64'),
    pii: Buffer.from(pii.bytes).toString('base64')
  }
}));

store.close();
"@ -- $recordsJson 2>&1
    
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='dpapi-store'; status='FAIL'; reason='store-failed'; code=$LASTEXITCODE }
      exit 1
    }
    
    $storeData = $retrieveResult | ConvertFrom-Json
    if ($storeData.status -ne 'OK') {
      Write-Status @{ stage='dpapi-store'; status='FAIL'; reason=$storeData.reason }
      exit 1
    }
    
    $script:keys = $storeData.keys
    Write-Status @{ stage='dpapi-store'; status='OK' }
  } finally {
    Pop-Location
  }
  
  # Encrypted SQLite
  Write-Stage "encrypted-sqlite"
  Push-Location $tempDir
  try {
    $dbPath = Join-Path $dataDir 'test.sqlite'
    $dbKey = $script:keys.db
    
    $sqliteResult = & pnpm exec tsx -e @"
import { openEncryptedSqlite } from './adapters/db-sqlite/src/index.ts';

const dbPath = process.argv[process.argv.length - 2];
const keyBase64 = process.argv[process.argv.length - 1];
const key = Buffer.from(keyBase64, 'base64');

try {
  const db = openEncryptedSqlite({ filename: dbPath, key });
  
  // Apply test migration
  db.applyMigrations([{
    name: '0001_test.sql',
    sql: 'CREATE TABLE IF NOT EXISTS test_proof (id INTEGER PRIMARY KEY, value TEXT);'
  }]);
  
  // Insert and read
  db.run('INSERT INTO test_proof (value) VALUES (?)', ['proof-value']);
  const row = db.first('SELECT value FROM test_proof WHERE id = ?', [1]);
  
  if (row?.value !== 'proof-value') {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'data-mismatch' }));
    process.exit(1);
  }
  
  db.close();
  console.log(JSON.stringify({ status: 'OK' }));
} catch (err) {
  console.log(JSON.stringify({ status: 'FAIL', reason: err.message }));
  process.exit(1);
}
"@ -- $dbPath $dbKey 2>&1
    
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='encrypted-sqlite'; status='FAIL'; reason='sqlite-failed'; code=$LASTEXITCODE }
      exit 1
    }
    
    $sqliteData = $sqliteResult | ConvertFrom-Json
    if ($sqliteData.status -ne 'OK') {
      Write-Status @{ stage='encrypted-sqlite'; status='FAIL'; reason=$sqliteData.reason }
      exit 1
    }
    
    Write-Status @{ stage='encrypted-sqlite'; status='OK' }
  } finally {
    Pop-Location
  }
  
  # Audio store
  Write-Stage "audio-store"
  Push-Location $tempDir
  try {
    $audioDir = Join-Path $dataDir 'audio'
    $fileKey = $script:keys.file
    
    $audioResult = & pnpm exec tsx -e @"
import { mkdir, access, constants } from 'node:fs/promises';
import { createFileAudioStore } from './adapters/audio-file/src/index.ts';

const audioDir = process.argv[process.argv.length - 2];
const keyBase64 = process.argv[process.argv.length - 1];
const key = { bytes: Buffer.from(keyBase64, 'base64'), version: 1 };

await mkdir(audioDir, { recursive: true });

try {
  const store = await createFileAudioStore(audioDir, key);
  await access(audioDir, constants.R_OK | constants.W_OK);
  console.log(JSON.stringify({ status: 'OK' }));
} catch (err) {
  console.log(JSON.stringify({ status: 'FAIL', reason: err.message }));
  process.exit(1);
}
"@ -- $audioDir $fileKey 2>&1
    
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='audio-store'; status='FAIL'; reason='audio-failed'; code=$LASTEXITCODE }
      exit 1
    }
    
    $audioData = $audioResult | ConvertFrom-Json
    if ($audioData.status -ne 'OK') {
      Write-Status @{ stage='audio-store'; status='FAIL'; reason=$audioData.reason }
      exit 1
    }
    
    Write-Status @{ stage='audio-store'; status='OK' }
  } finally {
    Pop-Location
  }
  
  # Scheduler tick
  Write-Stage "scheduler"
  Push-Location $tempDir
  try {
    $schedulerResult = & pnpm exec tsx -e @"
import { createNodeScheduler } from './adapters/scheduler-node/src/index.ts';

let tickCount = 0;
const scheduler = createNodeScheduler(
  async (jobName) => { tickCount++; },
  (failure) => { /* silent */ }
);

try {
  // Schedule job that runs every second
  await scheduler.schedule('test_job', '* * * * * *');
  
  // Wait for one tick (max 2 seconds)
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  await scheduler.close();
  
  if (tickCount === 0) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'no-tick' }));
    process.exit(1);
  }
  
  console.log(JSON.stringify({ status: 'OK', ticks: tickCount }));
} catch (err) {
  console.log(JSON.stringify({ status: 'FAIL', reason: err.message }));
  process.exit(1);
}
"@ 2>&1
    
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='scheduler'; status='FAIL'; reason='scheduler-failed'; code=$LASTEXITCODE }
      exit 1
    }
    
    $schedulerData = $schedulerResult | ConvertFrom-Json
    if ($schedulerData.status -ne 'OK') {
      Write-Status @{ stage='scheduler'; status='FAIL'; reason=$schedulerData.reason }
      exit 1
    }
    
    Write-Status @{ stage='scheduler'; status='OK'; ticks=$schedulerData.ticks }
  } finally {
    Pop-Location
  }
  
  # Identity creation and bearer verification
  Write-Stage "identity"
  Push-Location $tempDir
  try {
    $identityResult = & pnpm exec tsx -e @"
import { createLocalSingleIdentity } from './apps/local-service/src/identity.ts';

try {
  const identity = createLocalSingleIdentity({
    interactiveUsername: 'TestProofUser',
    orgId: 'proof-org-123',
  });
  
  // Verify bearer format (no key material exposure)
  if (!identity.bearer.startsWith('CCC-LOCAL-SINGLEv1-')) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'invalid-bearer-prefix' }));
    process.exit(1);
  }
  
  // Verify stable user ID (no raw username)
  const lowerUser = identity.stableUserId.toLowerCase();
  if (lowerUser.includes('testproofuser')) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'raw-username-in-id' }));
    process.exit(1);
  }
  
  // Create request with bearer and verify resolution
  const request = new Request('http://127.0.0.1:9999/test', {
    headers: { authorization: 'Bearer ' + identity.bearer }
  });
  
  const actor = await identity.resolve(request);
  
  if (actor.kind !== 'human' || actor.userId !== identity.stableUserId) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'actor-mismatch' }));
    process.exit(1);
  }
  
  identity.close();
  console.log(JSON.stringify({ status: 'OK' }));
} catch (err) {
  console.log(JSON.stringify({ status: 'FAIL', reason: err.message }));
  process.exit(1);
}
"@ 2>&1
    
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='identity'; status='FAIL'; reason='identity-failed'; code=$LASTEXITCODE }
      exit 1
    }
    
    $identityData = $identityResult | ConvertFrom-Json
    if ($identityData.status -ne 'OK') {
      Write-Status @{ stage='identity'; status='FAIL'; reason=$identityData.reason }
      exit 1
    }
    
    Write-Status @{ stage='identity'; status='OK' }
  } finally {
    Pop-Location
  }
  
  # Endpoint record file permissions
  Write-Stage "endpoint-record"
  Push-Location $tempDir
  try {
    $endpointPath = Join-Path $dataDir 'endpoint.json'
    
    $endpointResult = & pnpm exec tsx -e @"
import { writeFile, readFile, access, constants, stat } from 'node:fs/promises';

const endpointPath = process.argv[process.argv.length - 1];

const record = { installationId: 'proof-install-123', port: 12345 };
await writeFile(endpointPath, JSON.stringify(record), { mode: 0o600 });

try {
  await stat(endpointPath);
  await access(endpointPath, constants.R_OK);
  
  const content = await readFile(endpointPath, 'utf-8');
  const parsed = JSON.parse(content);
  
  if (parsed.installationId !== 'proof-install-123' || parsed.port !== 12345) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'content-mismatch' }));
    process.exit(1);
  }
  
  console.log(JSON.stringify({ status: 'OK' }));
} catch (err) {
  console.log(JSON.stringify({ status: 'FAIL', reason: err.message }));
  process.exit(1);
}
"@ -- $endpointPath 2>&1
    
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='endpoint-record'; status='FAIL'; reason='endpoint-failed'; code=$LASTEXITCODE }
      exit 1
    }
    
    $endpointData = $endpointResult | ConvertFrom-Json
    if ($endpointData.status -ne 'OK') {
      Write-Status @{ stage='endpoint-record'; status='FAIL'; reason=$endpointData.reason }
      exit 1
    }
    
    Write-Status @{ stage='endpoint-record'; status='OK' }
  } finally {
    Pop-Location
  }
  
  # Cleanup keys
  Write-Stage "cleanup-keys"
  # Keys were in PowerShell variables, clear them
  $script:keys = $null
  $script:records = $null
  Write-Status @{ stage='cleanup-keys'; status='OK' }
  
  # Run local-service unit tests
  Write-Stage "local-service-tests"
  Push-Location (Join-Path $tempDir 'apps/local-service')
  try {
    $testOutput = & pnpm exec tsx --test test/contract.test.ts 2>&1
    if ($LASTEXITCODE -ne 0) {
      Write-Status @{ stage='local-service-tests'; status='FAIL'; reason='tests-failed'; code=$LASTEXITCODE }
      exit 1
    }
    Write-Status @{ stage='local-service-tests'; status='OK' }
  } finally {
    Pop-Location
  }
  
  Write-Stage "complete"
  Write-Status @{ stage='complete'; status='OK'; commit='a4bdc0f' }
  
} finally {
  # Cleanup
  Write-Stage "cleanup"
  if (Test-Path $tempDir) {
    Remove-Item -Path $tempDir -Recurse -Force -ErrorAction SilentlyContinue
  }
  Write-Status @{ stage='cleanup'; status='OK' }
}
