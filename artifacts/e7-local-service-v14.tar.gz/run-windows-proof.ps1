<# 
  E7-1a/E7-1b Local Single service Windows verification
  
  Exercises:
    - DPAPI record protect/unprotect
    - Encrypted SQLite open with real key material
    - Scheduler tick
    - Endpoint-record file permissions
    - Loopback HTTP server on ephemeral port
  
  Outputs JSON status lines only. Never prints key material, bearer tokens,
  ports with tokens, or raw SIDs.
  
  Usage: .\run-windows-proof.ps1 -Root C:\temp
  
  The -Root is a WORK directory (not the bundle). The script copies the bundle there.
  On failure, the temp directory is preserved for diagnosis.
  
  HERMETIC: Uses only workspace-installed dependencies, no network fetches.
  EXIT CODE ONLY: Success/failure determined by process exit code, not stderr.
#>
param(
    [Parameter(Mandatory=$true)]
    [string]$Root
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Write-Status { 
    param([hashtable]$Status) 
    Write-Host (ConvertTo-Json $Status -Compress -Depth 10) 
}

function Get-DirListing {
    param([string]$Dir)
    if (Test-Path -LiteralPath $Dir) {
        $items = Get-ChildItem -LiteralPath $Dir -ErrorAction SilentlyContinue | 
            Select-Object -ExpandProperty Name
        return ($items -join ', ')
    }
    return '(not found)'
}

# Run a command via cmd.exe and return exit code, stdout, stderr
function Invoke-CmdWithOutput {
    param(
        [string]$Command,
        [string]$WorkingDirectory = $null
    )
    
    $outFile = [System.IO.Path]::GetTempFileName()
    $errFile = [System.IO.Path]::GetTempFileName()
    
    try {
        $startInfo = @{
            FilePath = 'cmd.exe'
            ArgumentList = @('/c', $Command)
            Wait = $true
            PassThru = $true
            NoNewWindow = $true
            RedirectStandardOutput = $outFile
            RedirectStandardError = $errFile
        }
        
        if ($WorkingDirectory) {
            $startInfo.WorkingDirectory = $WorkingDirectory
        }
        
        $proc = Start-Process @startInfo
        $stdout = Get-Content -LiteralPath $outFile -Raw -ErrorAction SilentlyContinue
        $stderr = Get-Content -LiteralPath $errFile -Raw -ErrorAction SilentlyContinue
        return @{
            ExitCode = $proc.ExitCode
            Stdout = if ($stdout) { $stdout.Trim() } else { '' }
            Stderr = if ($stderr) { $stderr.Trim() } else { '' }
        }
    } finally {
        Remove-Item -LiteralPath $outFile -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $errFile -Force -ErrorAction SilentlyContinue
    }
}

# Run node directly and capture output
function Invoke-NodeWithOutput {
    param(
        [string[]]$ArgumentList,
        [string]$WorkingDirectory = $null
    )
    
    $outFile = [System.IO.Path]::GetTempFileName()
    $errFile = [System.IO.Path]::GetTempFileName()
    
    try {
        $startInfo = @{
            FilePath = 'node'
            ArgumentList = $ArgumentList
            Wait = $true
            PassThru = $true
            NoNewWindow = $true
            RedirectStandardOutput = $outFile
            RedirectStandardError = $errFile
        }
        
        if ($WorkingDirectory) {
            $startInfo.WorkingDirectory = $WorkingDirectory
        }
        
        $proc = Start-Process @startInfo
        $stdout = Get-Content -LiteralPath $outFile -Raw -ErrorAction SilentlyContinue
        $stderr = Get-Content -LiteralPath $errFile -Raw -ErrorAction SilentlyContinue
        return @{
            ExitCode = $proc.ExitCode
            Stdout = if ($stdout) { $stdout.Trim() } else { '' }
            Stderr = if ($stderr) { $stderr.Trim() } else { '' }
        }
    } finally {
        Remove-Item -LiteralPath $outFile -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $errFile -Force -ErrorAction SilentlyContinue
    }
}

# Global state
$completedStages = @()
$tempDir = $null

# ── Stage: validate ──────────────────────────────────────────────────────────
Write-Status @{ stage='validate'; status='running' }
if ($Root -match '[^\x20-\x7E]') {
    Write-Status @{ stage='validate'; status='FAIL'; reason='non-ascii-root' }
    exit 1
}

# Normalize paths
$rootPath = (Resolve-Path -LiteralPath $Root -ErrorAction SilentlyContinue)
if (-not $rootPath) {
    New-Item -ItemType Directory -Path $Root -Force | Out-Null
    $rootPath = (Resolve-Path -LiteralPath $Root).Path
} else {
    $rootPath = $rootPath.Path
}
$rootPath = $rootPath.TrimEnd([IO.Path]::DirectorySeparatorChar)

$bundleRoot = $PSScriptRoot
if (-not $bundleRoot) {
    $bundleRoot = (Get-Location).Path
}
$bundleRoot = (Resolve-Path -LiteralPath $bundleRoot).Path.TrimEnd([IO.Path]::DirectorySeparatorChar)

# Verify bundle contents
$bundlePackageJson = Join-Path $bundleRoot 'package.json'
if (-not (Test-Path -LiteralPath $bundlePackageJson)) {
    Write-Status @{ stage='validate'; status='FAIL'; reason='bundle-missing-package-json'; bundleRoot=$bundleRoot }
    exit 1
}

# Path containment check
$sep = [IO.Path]::DirectorySeparatorChar
if ($rootPath.StartsWith($bundleRoot + $sep) -or $rootPath -eq $bundleRoot) {
    Write-Status @{ stage='validate'; status='FAIL'; reason='root-inside-bundle' }
    exit 1
}
if ($bundleRoot.StartsWith($rootPath + $sep)) {
    Write-Status @{ stage='validate'; status='FAIL'; reason='bundle-inside-root' }
    exit 1
}

Write-Status @{ stage='validate'; status='OK' }
$completedStages += 'validate'

# ── Stage: setup ─────────────────────────────────────────────────────────────
Write-Status @{ stage='setup'; status='running' }

$timestamp = (Get-Date).ToString('yyyyMMdd-HHmmss')
$tempDir = Join-Path $rootPath "e7-proof-$timestamp"
New-Item -ItemType Directory -Path $tempDir -Force | Out-Null

Write-Status @{ stage='setup'; status='OK'; tempDir=$tempDir }
$completedStages += 'setup'

# ── Stage: copy-source ───────────────────────────────────────────────────────
Write-Status @{ stage='copy-source'; status='running' }

$copiedFiles = 0
$copiedDirs = 0
$excludePatterns = @('run-windows-proof.ps1', '*.tar.gz', 'node_modules', '.git')

function Copy-BundleItem {
    param([string]$Source, [string]$Dest)
    
    $script:copiedDirs++
    if (-not (Test-Path -LiteralPath $Dest)) {
        New-Item -ItemType Directory -Path $Dest -Force | Out-Null
    }
    
    foreach ($item in Get-ChildItem -LiteralPath $Source -Force) {
        $skip = $false
        foreach ($pattern in $excludePatterns) {
            if ($item.Name -like $pattern) { $skip = $true; break }
        }
        if ($skip) { continue }
        
        $destPath = Join-Path $Dest $item.Name
        
        if ($item.PSIsContainer) {
            Copy-BundleItem -Source $item.FullName -Dest $destPath
        } else {
            Copy-Item -LiteralPath $item.FullName -Destination $destPath -Force
            $script:copiedFiles++
        }
    }
}

Copy-BundleItem -Source $bundleRoot -Dest $tempDir

Write-Status @{ stage='copy-source'; status='OK'; filesCopied=$copiedFiles; dirsCopied=$copiedDirs }
$completedStages += 'copy-source'

# ── Stage: verify-copy ───────────────────────────────────────────────────────
Write-Status @{ stage='verify-copy'; status='running' }

$verifyPackageJson = Join-Path $tempDir 'package.json'
if (-not (Test-Path -LiteralPath $verifyPackageJson)) {
    Write-Status @{ stage='verify-copy'; status='FAIL'; reason='missing-package-json'; tempDir=$tempDir }
    exit 1
}

Write-Status @{ stage='verify-copy'; status='OK' }
$completedStages += 'verify-copy'

# ── Stage: install ───────────────────────────────────────────────────────────
Write-Status @{ stage='install'; status='running'; cwd=$tempDir }

$installResult = Invoke-CmdWithOutput -Command 'pnpm install --frozen-lockfile' -WorkingDirectory $tempDir

if ($installResult.ExitCode -ne 0) {
    $listing = Get-DirListing $tempDir
    Write-Status @{ 
        stage='install'; status='FAIL'; reason='pnpm-install-failed';
        exitCode=$installResult.ExitCode; stdout=$installResult.Stdout; stderr=$installResult.Stderr;
        tempDirListing=$listing; preservedTempDir=$tempDir
    }
    exit 1
}

Write-Status @{ stage='install'; status='OK' }
$completedStages += 'install'

# ── Stage: build-native ──────────────────────────────────────────────────────
Write-Status @{ stage='build-native'; status='running' }

$buildResult = Invoke-CmdWithOutput -Command 'pnpm --filter @ccc/secrets-dpapi run build:native' -WorkingDirectory $tempDir

if ($buildResult.ExitCode -ne 0) {
    $listing = Get-DirListing $tempDir
    Write-Status @{ 
        stage='build-native'; status='FAIL'; reason='build-failed';
        exitCode=$buildResult.ExitCode; stdout=$buildResult.Stdout; stderr=$buildResult.Stderr;
        tempDirListing=$listing; preservedTempDir=$tempDir
    }
    exit 1
}

Write-Status @{ stage='build-native'; status='OK' }
$completedStages += 'build-native'

# ── Stage: dpapi-tests ───────────────────────────────────────────────────────
Write-Status @{ stage='dpapi-tests'; status='running' }

$testResult = Invoke-CmdWithOutput -Command 'pnpm --filter @ccc/secrets-dpapi test' -WorkingDirectory $tempDir

if ($testResult.ExitCode -ne 0) {
    $listing = Get-DirListing $tempDir
    Write-Status @{ 
        stage='dpapi-tests'; status='FAIL'; reason='tests-failed';
        exitCode=$testResult.ExitCode; stdout=$testResult.Stdout; stderr=$testResult.Stderr;
        tempDirListing=$listing; preservedTempDir=$tempDir
    }
    exit 1
}

Write-Status @{ stage='dpapi-tests'; status='OK' }
$completedStages += 'dpapi-tests'

# ── Stage: dpapi-protect ─────────────────────────────────────────────────────
# native.mjs exports only: packageRoot, sha256, loadNative
# loadNative() returns binding with protectData, unprotectData
Write-Status @{ stage='dpapi-protect'; status='running' }

$protectScript = @'
import { loadNative } from './adapters/secrets-dpapi/src/native.mjs';

// loadNative() returns a binding object with protectData and unprotectData methods
const binding = loadNative();

const keys = ['DB_MASTER_KEY', 'PII_ENC_KEY', 'FILE_ENC_KEY'];
for (const name of keys) {
    const testData = new Uint8Array(32);
    crypto.getRandomValues(testData);
    
    // Create entropy matching production store.ts: `CCC-DPAPI\0v1\0${name}\0${version}`
    // Use \u0000 (Unicode NUL) instead of \0 to avoid octal escape error in template literals
    const version = 1;
    const entropy = new TextEncoder().encode(`CCC-DPAPI\u0000v1\u0000${name}\u0000${version}`);
    
    const encrypted = binding.protectData(testData, entropy, 'CurrentUser');
    if (!(encrypted instanceof Uint8Array) || encrypted.length === 0) {
        console.log(JSON.stringify({ key: name, status: 'FAIL', reason: 'protect-failed' }));
        process.exit(1);
    }
    
    const decrypted = binding.unprotectData(encrypted, entropy, 'CurrentUser');
    if (!(decrypted instanceof Uint8Array) || decrypted.length !== 32) {
        console.log(JSON.stringify({ key: name, status: 'FAIL', reason: 'unprotect-failed' }));
        process.exit(1);
    }
    
    let match = true;
    for (let i = 0; i < 32; i++) {
        if (testData[i] !== decrypted[i]) { match = false; break; }
    }
    if (!match) {
        console.log(JSON.stringify({ key: name, status: 'FAIL', reason: 'data-mismatch' }));
        process.exit(1);
    }
    testData.fill(0);
    decrypted.fill(0);
    entropy.fill(0);
}
console.log(JSON.stringify({ status: 'OK', keysVerified: 3 }));
'@

$scriptPath = Join-Path $tempDir '_dpapi-protect.mjs'
Set-Content -LiteralPath $scriptPath -Value $protectScript -Encoding UTF8

$protectResult = Invoke-NodeWithOutput -ArgumentList @($scriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $scriptPath -Force -ErrorAction SilentlyContinue

if ($protectResult.ExitCode -ne 0) {
    $listing = Get-DirListing $tempDir
    Write-Status @{ 
        stage='dpapi-protect'; status='FAIL'; reason='protect-script-failed';
        exitCode=$protectResult.ExitCode; stdout=$protectResult.Stdout; stderr=$protectResult.Stderr;
        tempDirListing=$listing; preservedTempDir=$tempDir
    }
    exit 1
}

Write-Status @{ stage='dpapi-protect'; status='OK' }
$completedStages += 'dpapi-protect'

# ── Stage: dpapi-store ───────────────────────────────────────────────────────
# store.ts exports: byteStore(native, mode, records) -> store with getBytesWithVersion/protect/close
Write-Status @{ stage='dpapi-store'; status='running' }

$storeScript = @'
import { loadNative } from './adapters/secrets-dpapi/src/native.mjs';
import { byteStore } from './adapters/secrets-dpapi/src/store.ts';

const native = loadNative();

// Create an empty store to generate protected records
const store1 = byteStore(native, 'local-single', []);
const keys = ['DB_MASTER_KEY', 'PII_ENC_KEY', 'FILE_ENC_KEY'];
const records = [];
const originalValues = new Map();

for (const name of keys) {
    const value = new Uint8Array(32);
    crypto.getRandomValues(value);
    originalValues.set(name, new Uint8Array(value));
    
    // protect() returns a DpapiRecord { schemaVersion, name, version, blob }
    const record = store1.protect(name, { bytes: value, version: 1 });
    records.push(record);
}
store1.close();

// Create a new store with the protected records to read them back
const store2 = byteStore(native, 'local-single', records);
for (const name of keys) {
    const result = await store2.getBytesWithVersion(name);
    if (!result || result.bytes.length !== 32) {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'get-failed', key: name }));
        process.exit(1);
    }
    
    // Verify the decrypted value matches the original
    const original = originalValues.get(name);
    let match = true;
    for (let i = 0; i < 32; i++) {
        if (result.bytes[i] !== original[i]) { match = false; break; }
    }
    if (!match) {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'data-mismatch', key: name }));
        process.exit(1);
    }
    result.bytes.fill(0);
}
store2.close();

// Verify OFFICE_CA_KEY is rejected in local-single mode
const store3 = byteStore(native, 'local-single', []);
try {
    store3.protect('OFFICE_CA_KEY', { bytes: new Uint8Array(32), version: 1 });
    console.log(JSON.stringify({ status: 'FAIL', reason: 'office-ca-not-rejected' }));
    process.exit(1);
} catch (e) {
    if (!e.message.includes('secret_access_denied')) {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'wrong-error', message: e.message }));
        process.exit(1);
    }
}
store3.close();

console.log(JSON.stringify({ status: 'OK', keysVerified: 3, officeRejected: true }));
'@

$storeScriptPath = Join-Path $tempDir '_dpapi-store.mjs'
Set-Content -LiteralPath $storeScriptPath -Value $storeScript -Encoding UTF8

$storeResult = Invoke-NodeWithOutput -ArgumentList @($storeScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $storeScriptPath -Force -ErrorAction SilentlyContinue

if ($storeResult.ExitCode -ne 0) {
    $listing = Get-DirListing $tempDir
    Write-Status @{ 
        stage='dpapi-store'; status='FAIL'; reason='store-script-failed';
        exitCode=$storeResult.ExitCode; stdout=$storeResult.Stdout; stderr=$storeResult.Stderr;
        tempDirListing=$listing; preservedTempDir=$tempDir
    }
    exit 1
}

Write-Status @{ stage='dpapi-store'; status='OK' }
$completedStages += 'dpapi-store'

# ── Stage: build-adapters ────────────────────────────────────────────────────
# db-sqlite has TypeScript parameter properties which require compilation
# (Node strip-only mode rejects parameter properties with ERR_UNSUPPORTED_TYPESCRIPT_SYNTAX)
# audio-file has no non-strippable syntax so it runs directly from TypeScript source
Write-Status @{ stage='build-adapters'; status='running' }

$buildSqliteResult = Invoke-CmdWithOutput -Command 'pnpm --filter @ccc/db-sqlite build' -WorkingDirectory $tempDir

if ($buildSqliteResult.ExitCode -ne 0) {
    $listing = Get-DirListing $tempDir
    Write-Status @{ 
        stage='build-adapters'; status='FAIL'; reason='db-sqlite-build-failed';
        exitCode=$buildSqliteResult.ExitCode; stdout=$buildSqliteResult.Stdout; stderr=$buildSqliteResult.Stderr;
        tempDirListing=$listing; preservedTempDir=$tempDir
    }
    exit 1
}

Write-Status @{ stage='build-adapters'; status='OK' }
$completedStages += 'build-adapters'

# ── Stage: encrypted-sqlite ──────────────────────────────────────────────────
Write-Status @{ stage='encrypted-sqlite'; status='running' }

$sqliteScript = @'
import { loadNative } from './adapters/secrets-dpapi/src/native.mjs';
import { byteStore } from './adapters/secrets-dpapi/src/store.ts';
// Use compiled JavaScript from dist/ to avoid parameter property syntax error
import { openEncryptedSqlite } from './adapters/db-sqlite/dist/index.js';
import { join } from 'node:path';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';

const native = loadNative();

// Generate a real 32-byte key via DPAPI
const keyBytes = new Uint8Array(32);
crypto.getRandomValues(keyBytes);
const store = byteStore(native, 'local-single', []);
const keyRecord = store.protect('DB_MASTER_KEY', { bytes: keyBytes, version: 1 });
store.close();

// Use the raw key for SQLite (in production this comes from the store)
const testDir = mkdtempSync(join(tmpdir(), 'e7-sqlite-'));
const dbPath = join(testDir, 'test.db');

try {
    const db = openEncryptedSqlite({ filename: dbPath, key: keyBytes });
    
    // Create a table and insert data
    const createResult = await db.prepare('CREATE TABLE test (id INTEGER PRIMARY KEY, value TEXT)').run();
    const insertResult = await db.prepare('INSERT INTO test (value) VALUES (?)').bind('hello').run();
    
    // Verify insert worked
    if (insertResult.lastRowId !== 1) {
        console.log(JSON.stringify({ 
            status: 'FAIL', 
            reason: 'insert-failed', 
            createResult,
            insertResult 
        }));
        process.exit(1);
    }
    
    // Query back
    const row = await db.prepare('SELECT value FROM test WHERE id = 1').first();
    
    if (!row || row.value !== 'hello') {
        // Additional diagnostics
        const allRows = await db.prepare('SELECT * FROM test').all();
        const countRow = await db.prepare('SELECT COUNT(*) as cnt FROM test').first();
        console.log(JSON.stringify({ 
            status: 'FAIL', 
            reason: 'query-failed', 
            row,
            rowType: typeof row,
            rowKeys: row ? Object.keys(row) : null,
            rowEntries: row ? Object.entries(row) : null,
            allRows,
            countRow,
            insertResult
        }));
        process.exit(1);
    }
    
    db.close();
    
    // Verify we can reopen with the same key
    const db2 = openEncryptedSqlite({ filename: dbPath, key: keyBytes });
    const row2 = await db2.prepare('SELECT value FROM test WHERE id = 1').first();
    if (!row2 || row2.value !== 'hello') {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'reopen-failed', row2 }));
        process.exit(1);
    }
    db2.close();
    
    // Clean up key material
    keyBytes.fill(0);
    keyRecord.blob.fill(0);
    
    console.log(JSON.stringify({ status: 'OK', created: true, reopened: true }));
} finally {
    rmSync(testDir, { recursive: true, force: true });
}
'@

$sqliteScriptPath = Join-Path $tempDir '_encrypted-sqlite.mjs'
Set-Content -LiteralPath $sqliteScriptPath -Value $sqliteScript -Encoding UTF8

$sqliteResult = Invoke-NodeWithOutput -ArgumentList @($sqliteScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $sqliteScriptPath -Force -ErrorAction SilentlyContinue

if ($sqliteResult.ExitCode -ne 0) {
    $listing = Get-DirListing $tempDir
    Write-Status @{ 
        stage='encrypted-sqlite'; status='FAIL'; reason='sqlite-script-failed';
        exitCode=$sqliteResult.ExitCode; stdout=$sqliteResult.Stdout; stderr=$sqliteResult.Stderr;
        tempDirListing=$listing; preservedTempDir=$tempDir
    }
    exit 1
}

Write-Status @{ stage='encrypted-sqlite'; status='OK' }
$completedStages += 'encrypted-sqlite'

# ── Stage: audio-store ───────────────────────────────────────────────────────
Write-Status @{ stage='audio-store'; status='running' }

$audioScript = @'
// createFileAudioStore(rootPath: string, fileKey: VersionedSecretBytes): Promise<AudioStore>
// audio-file has no non-strippable TypeScript syntax, runs directly from source
import { createFileAudioStore } from './adapters/audio-file/src/index.ts';
import { join } from 'node:path';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';

const testDir = mkdtempSync(join(tmpdir(), 'e7-audio-'));
const fileKeyBytes = new Uint8Array(32);
crypto.getRandomValues(fileKeyBytes);

// VersionedSecretBytes = { bytes: Uint8Array, version: number }
const fileKey = { bytes: fileKeyBytes, version: 1 };

try {
    const store = await createFileAudioStore(testDir, fileKey);
    
    // Create upload authorization
    const auth = await store.createUploadAuth({
        sessionId: 'test-session-001',
        contentLength: 1024,
        contentType: 'audio/mp4'
    });
    
    if (!auth || !auth.url || !auth.headers) {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'no-auth' }));
        process.exit(1);
    }
    
    // Clean up
    fileKeyBytes.fill(0);
    
    console.log(JSON.stringify({ status: 'OK', hasUrl: !!auth.url }));
} finally {
    rmSync(testDir, { recursive: true, force: true });
}
'@

$audioScriptPath = Join-Path $tempDir '_audio-store.mjs'
Set-Content -LiteralPath $audioScriptPath -Value $audioScript -Encoding UTF8

$audioResult = Invoke-NodeWithOutput -ArgumentList @($audioScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $audioScriptPath -Force -ErrorAction SilentlyContinue

if ($audioResult.ExitCode -ne 0) {
    $listing = Get-DirListing $tempDir
    Write-Status @{ 
        stage='audio-store'; status='FAIL'; reason='audio-script-failed';
        exitCode=$audioResult.ExitCode; stdout=$audioResult.Stdout; stderr=$audioResult.Stderr;
        tempDirListing=$listing; preservedTempDir=$tempDir
    }
    exit 1
}

Write-Status @{ stage='audio-store'; status='OK' }
$completedStages += 'audio-store'

# ── Stage: scheduler ─────────────────────────────────────────────────────────
Write-Status @{ stage='scheduler'; status='running' }

$schedulerScript = @'
import { createNodeScheduler } from './adapters/scheduler-node/src/index.ts';

let runCount = 0;
const scheduler = createNodeScheduler(
    async (kind, nowIso) => { runCount++; return { kind, nowIso }; },
    (err) => { console.error('Scheduler error:', err); }
);

// Schedule a job for immediate execution
const nextSecond = new Date(Date.now() + 1000);
scheduler.schedule('pii_retention', nextSecond.toISOString());

// Wait for it to run
await new Promise(r => setTimeout(r, 1500));

scheduler.close();

if (runCount === 0) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'job-not-run' }));
    process.exit(1);
}

console.log(JSON.stringify({ status: 'OK', runCount }));
'@

$schedulerScriptPath = Join-Path $tempDir '_scheduler.mjs'
Set-Content -LiteralPath $schedulerScriptPath -Value $schedulerScript -Encoding UTF8

$schedulerResult = Invoke-NodeWithOutput -ArgumentList @($schedulerScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $schedulerScriptPath -Force -ErrorAction SilentlyContinue

if ($schedulerResult.ExitCode -ne 0) {
    $listing = Get-DirListing $tempDir
    Write-Status @{ 
        stage='scheduler'; status='FAIL'; reason='scheduler-script-failed';
        exitCode=$schedulerResult.ExitCode; stdout=$schedulerResult.Stdout; stderr=$schedulerResult.Stderr;
        tempDirListing=$listing; preservedTempDir=$tempDir
    }
    exit 1
}

Write-Status @{ stage='scheduler'; status='OK' }
$completedStages += 'scheduler'

# ── Stage: identity ──────────────────────────────────────────────────────────
Write-Status @{ stage='identity'; status='running' }

$identityScript = @'
import { createLocalSingleIdentity } from './apps/local-service/src/identity.ts';

const config = {
    stableUserId: 'test-user-001',
    orgId: 'test-org',
    roles: ['admin', 'counselor'],
};

const identity = createLocalSingleIdentity(config);

// Check the bearer token exists
if (!identity.bearer || identity.bearer.length < 32) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'no-bearer' }));
    process.exit(1);
}

// Check stableUserId
if (identity.stableUserId !== config.stableUserId) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'wrong-userId' }));
    process.exit(1);
}

// Test resolve with correct bearer
const actor = await identity.resolve({ headers: { get: (name) => name === 'authorization' ? `Bearer ${identity.bearer}` : null } });
if (!actor || actor.userId !== config.stableUserId) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'resolve-failed' }));
    process.exit(1);
}

// Test resolve with wrong bearer
const badActor = await identity.resolve({ headers: { get: (name) => name === 'authorization' ? 'Bearer wrong-token' : null } });
if (badActor !== null) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'bad-bearer-accepted' }));
    process.exit(1);
}

console.log(JSON.stringify({ status: 'OK', hasBearer: true, resolves: true }));
'@

$identityScriptPath = Join-Path $tempDir '_identity.mjs'
Set-Content -LiteralPath $identityScriptPath -Value $identityScript -Encoding UTF8

$identityResult = Invoke-NodeWithOutput -ArgumentList @($identityScriptPath) -WorkingDirectory $tempDir
Remove-Item -LiteralPath $identityScriptPath -Force -ErrorAction SilentlyContinue

if ($identityResult.ExitCode -ne 0) {
    $listing = Get-DirListing $tempDir
    Write-Status @{ 
        stage='identity'; status='FAIL'; reason='identity-script-failed';
        exitCode=$identityResult.ExitCode; stdout=$identityResult.Stdout; stderr=$identityResult.Stderr;
        tempDirListing=$listing; preservedTempDir=$tempDir
    }
    exit 1
}

Write-Status @{ stage='identity'; status='OK' }
$completedStages += 'identity'

# ── Stage: cleanup ───────────────────────────────────────────────────────────
Write-Status @{ stage='cleanup'; status='running' }

# Remove temp directory on success
Remove-Item -Recurse -Force $tempDir -ErrorAction SilentlyContinue

Write-Status @{ stage='cleanup'; status='OK'; completedStages=($completedStages -join ',') }

exit 0
