import assert from 'node:assert/strict';
import { createDpapiSecretStore } from '../src/index.ts';

// Bundle-only synthetic proof. No credentials, accounts, ACLs or persisted key records.
const stores = [];
const buffers = [];
try {
  if (process.argv[2] === '--expect-unbuilt') {
    assert.throws(() => createDpapiSecretStore('local-single', []), /^Error: secret_access_denied$/);
    console.log(JSON.stringify({ status: 'unbuilt-loader-refused', platform: process.platform, node: process.version }));
  } else {
    assert.equal(process.platform, 'win32');
    const writer = createDpapiSecretStore('local-single', []); stores.push(writer);
    const synthetic = new Uint8Array(32).fill(25); buffers.push(synthetic);
    const records = ['DB_MASTER_KEY', 'FILE_ENC_KEY', 'PII_ENC_KEY'].map(name => writer.protect(name, { bytes: synthetic, version: 3 }));
    buffers.push(...records.map(record => record.blob));
    const reader = createDpapiSecretStore('local-single', records); stores.push(reader);
    for (const record of records) {
      const first = await reader.getBytesWithVersion(record.name); buffers.push(first.bytes);
      assert.equal(first.version, 3);
      assert.equal(Object.getPrototypeOf(first.bytes), Uint8Array.prototype);
      assert.deepEqual(first.bytes, synthetic);
      first.bytes.fill(0);
      const second = await reader.getBytesWithVersion(record.name); buffers.push(second.bytes);
      assert.deepEqual(second.bytes, synthetic);
    }
    const swapped = createDpapiSecretStore('local-single', [{ ...records[0], version: 4 }]); stores.push(swapped);
    await assert.rejects(swapped.getBytesWithVersion('DB_MASTER_KEY'), /^Error: secret_access_denied$/);
    reader.close();
    await assert.rejects(reader.getBytesWithVersion('DB_MASTER_KEY'), /^Error: secret_access_denied$/);
    assert.deepEqual(synthetic, new Uint8Array(32).fill(25));
    console.log(JSON.stringify({ status: 'synthetic-public-adapter-verified', platform: process.platform, arch: process.arch, node: process.version, keys: 3, persistence: false, recoveryKit: false }));
  }
} catch {
  console.error('secret_access_denied');
  process.exitCode = 1;
} finally {
  for (const store of stores) store.close();
  for (const buffer of buffers) buffer.fill(0);
}
