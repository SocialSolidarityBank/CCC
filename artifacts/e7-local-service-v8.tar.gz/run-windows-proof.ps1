<# 
  E7-1a/E7-1b Local Single service Windows verification
  
  Exercises:
    - DPAPI record protect/unprotect
    - Encrypted SQLite open with real key material
    - Scheduler tick
    - Endpoint-record file permissions
    - Loopback HTTP server on ephemeral port
  
  Outputs JSON status lines only. Never prints key material, bearer tokens,
  ports with tokens, or raw SIDs.
  
  Usage: .\run-windows-proof.ps1 -Root C:\temp
  
  The -Root is a WORK directory (not the bundle). The script copies the bundle there.
  On failure, the temp directory is preserved for diagnosis.
  
  HERMETIC: Uses only workspace-installed dependencies, no network fetches.
  EXIT CODE ONLY: Success/failure determined by process exit code, not stderr.
#>
param(
    [Parameter(Mandatory=$true)]
    [string]$Root
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

function Write-Status { 
    param([hashtable]$Status) 
    Write-Host (ConvertTo-Json $Status -Compress -Depth 10) 
}

function Get-DirListing {
    param([string]$Dir)
    if (Test-Path -LiteralPath $Dir) {
        $items = Get-ChildItem -LiteralPath $Dir -ErrorAction SilentlyContinue | 
            Select-Object -ExpandProperty Name
        return ($items -join ', ')
    }
    return '(not found)'
}

# Run a command via cmd.exe and return exit code only (ignores stderr warnings)
# Uses distinct temp files for stdout/stderr redirection
# This handles .cmd shims like pnpm.cmd on Windows
function Invoke-CmdExitCode {
    param(
        [string]$Command,
        [string]$WorkingDirectory = $null
    )
    
    $outFile = [System.IO.Path]::GetTempFileName()
    $errFile = [System.IO.Path]::GetTempFileName()
    
    try {
        $startInfo = @{
            FilePath = 'cmd.exe'
            ArgumentList = @('/c', $Command)
            Wait = $true
            PassThru = $true
            NoNewWindow = $true
            RedirectStandardOutput = $outFile
            RedirectStandardError = $errFile
        }
        
        if ($WorkingDirectory) {
            $startInfo.WorkingDirectory = $WorkingDirectory
        }
        
        $proc = Start-Process @startInfo
        return $proc.ExitCode
    } finally {
        Remove-Item -LiteralPath $outFile -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $errFile -Force -ErrorAction SilentlyContinue
    }
}

# Run node directly (not a .cmd shim)
function Invoke-NodeExitCode {
    param(
        [string[]]$ArgumentList,
        [string]$WorkingDirectory = $null
    )
    
    $outFile = [System.IO.Path]::GetTempFileName()
    $errFile = [System.IO.Path]::GetTempFileName()
    
    try {
        $startInfo = @{
            FilePath = 'node'
            ArgumentList = $ArgumentList
            Wait = $true
            PassThru = $true
            NoNewWindow = $true
            RedirectStandardOutput = $outFile
            RedirectStandardError = $errFile
        }
        
        if ($WorkingDirectory) {
            $startInfo.WorkingDirectory = $WorkingDirectory
        }
        
        $proc = Start-Process @startInfo
        return $proc.ExitCode
    } finally {
        Remove-Item -LiteralPath $outFile -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $errFile -Force -ErrorAction SilentlyContinue
    }
}

# Global state
$completedStages = @()
$tempDir = $null

# Validate ASCII root
Write-Status @{ stage='validate'; status='running' }
if ($Root -match '[^\x20-\x7E]') {
    Write-Status @{ stage='validate'; status='FAIL'; reason='non-ascii-root' }
    exit 1
}

# Normalize paths
$rootPath = (Resolve-Path -LiteralPath $Root -ErrorAction SilentlyContinue)
if (-not $rootPath) {
    New-Item -ItemType Directory -Path $Root -Force | Out-Null
    $rootPath = (Resolve-Path -LiteralPath $Root).Path
} else {
    $rootPath = $rootPath.Path
}
$rootPath = $rootPath.TrimEnd([IO.Path]::DirectorySeparatorChar)

$bundleRoot = $PSScriptRoot
if (-not $bundleRoot) {
    $bundleRoot = (Get-Location).Path
}
$bundleRoot = (Resolve-Path -LiteralPath $bundleRoot).Path.TrimEnd([IO.Path]::DirectorySeparatorChar)

# Verify bundle contents
$bundlePackageJson = Join-Path $bundleRoot 'package.json'
if (-not (Test-Path -LiteralPath $bundlePackageJson)) {
    Write-Status @{ stage='validate'; status='FAIL'; reason='bundle-missing-package-json'; bundleRoot=$bundleRoot }
    exit 1
}

# Path containment check
$sep = [IO.Path]::DirectorySeparatorChar
if ($rootPath.StartsWith($bundleRoot + $sep) -or $rootPath -eq $bundleRoot) {
    Write-Status @{ stage='validate'; status='FAIL'; reason='root-inside-bundle' }
    exit 1
}
if ($bundleRoot.StartsWith($rootPath + $sep)) {
    Write-Status @{ stage='validate'; status='FAIL'; reason='bundle-inside-root' }
    exit 1
}

Write-Status @{ stage='validate'; status='OK' }
$completedStages += 'validate'

try {
    # Setup temp directory
    Write-Status @{ stage='setup'; status='running' }
    $timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $tempDir = Join-Path $rootPath "e7-proof-$timestamp"
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    Write-Status @{ stage='setup'; status='OK'; tempDir=$tempDir }
    $completedStages += 'setup'

    # Copy source using robocopy
    Write-Status @{ stage='copy-source'; status='running' }
    
    $robocopyArgs = @(
        $bundleRoot,
        $tempDir,
        '/E', '/NFL', '/NDL', '/NJH', '/NJS', '/R:1', '/W:1',
        '/XF', 'run-windows-proof.ps1', '/XF', '._*', '/XF', '.DS_Store'
    )
    
    & robocopy @robocopyArgs | Out-Null
    $robocopyExit = $LASTEXITCODE
    
    if ($robocopyExit -ge 8) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='copy-source'; status='FAIL'; reason='robocopy-failed'; 
            exitCode=$robocopyExit; tempDirListing=$listing
        }
        exit 1
    }
    
    $copiedFiles = (Get-ChildItem -LiteralPath $tempDir -Recurse -File -ErrorAction SilentlyContinue | Measure-Object).Count
    $copiedDirs = (Get-ChildItem -LiteralPath $tempDir -Recurse -Directory -ErrorAction SilentlyContinue | Measure-Object).Count
    
    Write-Status @{ stage='copy-source'; status='OK'; filesCopied=$copiedFiles; dirsCopied=$copiedDirs }
    $completedStages += 'copy-source'

    # Verify required files
    Write-Status @{ stage='verify-copy'; status='running' }
    $requiredFiles = @('package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'tsconfig.base.json')
    $missingFiles = @()
    foreach ($f in $requiredFiles) {
        if (-not (Test-Path -LiteralPath (Join-Path $tempDir $f))) {
            $missingFiles += $f
        }
    }
    # Also verify patches directory
    $patchesDir = Join-Path $tempDir 'patches'
    if (-not (Test-Path -LiteralPath $patchesDir)) {
        $missingFiles += 'patches/'
    }
    
    if ($missingFiles.Count -gt 0) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='verify-copy'; status='FAIL'; reason='missing-required-files';
            missingFiles=($missingFiles -join ', '); tempDirListing=$listing
        }
        exit 1
    }
    
    Write-Status @{ stage='verify-copy'; status='OK' }
    $completedStages += 'verify-copy'

    # Install dependencies (hermetic: frozen lockfile, no scripts, no network for new packages)
    # Use cmd.exe /c because pnpm is a .cmd shim on Windows
    Write-Status @{ stage='install'; status='running'; cwd=$tempDir }
    
    $installExit = Invoke-CmdExitCode -Command 'pnpm install --frozen-lockfile --ignore-scripts' `
        -WorkingDirectory $tempDir
    
    if ($installExit -ne 0) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='install'; status='FAIL'; reason='pnpm-install-failed';
            exitCode=$installExit; tempDirListing=$listing; preservedTempDir=$tempDir
        }
        exit 1
    }
    
    Write-Status @{ stage='install'; status='OK' }
    $completedStages += 'install'

    # Build native DPAPI addon using pnpm run (hermetic: uses workspace scripts)
    Write-Status @{ stage='build-native'; status='running' }
    
    $buildExit = Invoke-CmdExitCode -Command 'pnpm --filter @ccc/secrets-dpapi run build:native' `
        -WorkingDirectory $tempDir
    
    if ($buildExit -ne 0) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='build-native'; status='FAIL'; reason='build-failed';
            exitCode=$buildExit; tempDirListing=$listing; preservedTempDir=$tempDir
        }
        exit 1
    }
    
    Write-Status @{ stage='build-native'; status='OK' }
    $completedStages += 'build-native'

    # Run DPAPI contract tests using pnpm run (hermetic: uses workspace test runner)
    Write-Status @{ stage='dpapi-tests'; status='running' }
    
    $testExit = Invoke-CmdExitCode -Command 'pnpm --filter @ccc/secrets-dpapi test' `
        -WorkingDirectory $tempDir
    
    if ($testExit -ne 0) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='dpapi-tests'; status='FAIL'; reason='tests-failed';
            exitCode=$testExit; tempDirListing=$listing; preservedTempDir=$tempDir
        }
        exit 1
    }
    
    Write-Status @{ stage='dpapi-tests'; status='OK' }
    $completedStages += 'dpapi-tests'

    # Test DPAPI protect/unprotect directly via Node
    # native.mjs exports loadNative() which returns binding with protectData/unprotectData
    Write-Status @{ stage='dpapi-protect'; status='running' }
    
    $protectScript = @'
import { loadNative } from './adapters/secrets-dpapi/src/native.mjs';

// loadNative() returns a binding object with protectData and unprotectData methods
const binding = loadNative();

const keys = ['DB_MASTER_KEY', 'PII_ENC_KEY', 'FILE_ENC_KEY'];
for (const name of keys) {
    const testData = new Uint8Array(32);
    crypto.getRandomValues(testData);
    
    // Create entropy matching what store.ts uses
    const entropy = new TextEncoder().encode(`CCC-DPAPI\0v1\0${name}\01`);
    
    const encrypted = binding.protectData(testData, entropy, 'CurrentUser');
    if (!(encrypted instanceof Uint8Array) || encrypted.length === 0) {
        console.log(JSON.stringify({ key: name, status: 'FAIL', reason: 'protect-failed' }));
        process.exit(1);
    }
    
    const decrypted = binding.unprotectData(encrypted, entropy, 'CurrentUser');
    if (!(decrypted instanceof Uint8Array) || decrypted.length !== 32) {
        console.log(JSON.stringify({ key: name, status: 'FAIL', reason: 'unprotect-failed' }));
        process.exit(1);
    }
    
    let match = true;
    for (let i = 0; i < 32; i++) {
        if (testData[i] !== decrypted[i]) { match = false; break; }
    }
    if (!match) {
        console.log(JSON.stringify({ key: name, status: 'FAIL', reason: 'data-mismatch' }));
        process.exit(1);
    }
    testData.fill(0);
    decrypted.fill(0);
    entropy.fill(0);
}
console.log(JSON.stringify({ status: 'OK', keysVerified: 3 }));
'@
    $scriptPath = Join-Path $tempDir '_dpapi-protect.mjs'
    Set-Content -LiteralPath $scriptPath -Value $protectScript -Encoding UTF8
    
    # Run with node directly (native.mjs is plain JS, no TypeScript needed)
    $protectExit = Invoke-NodeExitCode -ArgumentList @($scriptPath) -WorkingDirectory $tempDir
    
    Remove-Item -LiteralPath $scriptPath -Force -ErrorAction SilentlyContinue
    
    if ($protectExit -ne 0) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='dpapi-protect'; status='FAIL'; reason='protect-script-failed';
            exitCode=$protectExit; tempDirListing=$listing; preservedTempDir=$tempDir
        }
        exit 1
    }
    
    Write-Status @{ stage='dpapi-protect'; status='OK' }
    $completedStages += 'dpapi-protect'

    # Test DPAPI store using byteStore from store.ts
    # store.ts exports: byteStore(native, mode, records) -> store with getBytesWithVersion/protect/close
    Write-Status @{ stage='dpapi-store'; status='running' }
    
    $storeScript = @"
import { loadNative } from './adapters/secrets-dpapi/src/native.mjs';
import { byteStore } from './adapters/secrets-dpapi/src/store.ts';

const native = loadNative();

// Create an empty store to generate protected records
const store1 = byteStore(native, 'local-single', []);

const keys = ['DB_MASTER_KEY', 'PII_ENC_KEY', 'FILE_ENC_KEY'];
const records = [];
const originalValues = new Map();

for (const name of keys) {
    const value = new Uint8Array(32);
    crypto.getRandomValues(value);
    originalValues.set(name, new Uint8Array(value));
    
    // protect() returns a DpapiRecord { schemaVersion, name, version, blob }
    const record = store1.protect(name, { bytes: value, version: 1 });
    records.push(record);
}
store1.close();

// Create a new store with the protected records to read them back
const store2 = byteStore(native, 'local-single', records);

for (const name of keys) {
    const result = await store2.getBytesWithVersion(name);
    if (!result || result.bytes.length !== 32) {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'get-failed', key: name }));
        process.exit(1);
    }
    
    // Verify the decrypted value matches the original
    const original = originalValues.get(name);
    let match = true;
    for (let i = 0; i < 32; i++) {
        if (result.bytes[i] !== original[i]) { match = false; break; }
    }
    if (!match) {
        console.log(JSON.stringify({ status: 'FAIL', reason: 'value-mismatch', key: name }));
        process.exit(1);
    }
    result.bytes.fill(0);
}
store2.close();

// Clean up
for (const v of originalValues.values()) v.fill(0);

console.log(JSON.stringify({ status: 'OK', storedKeys: keys.length }));
"@
    $scriptPath = Join-Path $tempDir '_dpapi-store.ts'
    Set-Content -LiteralPath $scriptPath -Value $storeScript -Encoding UTF8
    
    $storeExit = Invoke-NodeExitCode -ArgumentList @('--experimental-strip-types', $scriptPath) `
        -WorkingDirectory $tempDir
    
    Remove-Item -LiteralPath $scriptPath -Force -ErrorAction SilentlyContinue
    
    if ($storeExit -ne 0) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='dpapi-store'; status='FAIL'; reason='store-script-failed';
            exitCode=$storeExit; tempDirListing=$listing; preservedTempDir=$tempDir
        }
        exit 1
    }
    
    Write-Status @{ stage='dpapi-store'; status='OK' }
    $completedStages += 'dpapi-store'

    # Test encrypted SQLite using openEncryptedSqlite
    Write-Status @{ stage='encrypted-sqlite'; status='running' }
    
    $dbPath = Join-Path $tempDir 'test.db'
    
    $sqliteScript = @"
import { openEncryptedSqlite } from './adapters/db-sqlite/src/index.ts';
import { readdirSync, readFileSync } from 'fs';
import { join } from 'path';

const dbPath = process.argv[2];
const migrationsDir = join(process.cwd(), 'migrations', 'sqlite');

const key = new Uint8Array(32);
crypto.getRandomValues(key);

const db = openEncryptedSqlite({ filename: dbPath, key });

// Apply first migration to create organizations table
const migrations = readdirSync(migrationsDir)
  .filter(n => n.endsWith('.sql'))
  .sort()
  .slice(0, 1)  // Just 0001_init.sql
  .map(name => ({ name, sql: readFileSync(join(migrationsDir, name), 'utf8') }));
db.applyMigrations(migrations);

// Insert a test row
await db.prepare("INSERT INTO organizations (id, name, created_at) VALUES (?, ?, ?)")
    .bind('test-org', 'Test Organization', new Date().toISOString())
    .run();

// Read back
const row = await db.prepare("SELECT name FROM organizations WHERE id = ?")
    .bind('test-org')
    .first('name');
if (row !== 'Test Organization') {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'read-mismatch', got: row }));
    db.close();
    process.exit(1);
}

db.close();
console.log(JSON.stringify({ status: 'OK' }));
"@
    $scriptPath = Join-Path $tempDir '_sqlite-test.ts'
    Set-Content -LiteralPath $scriptPath -Value $sqliteScript -Encoding UTF8
    
    $sqliteExit = Invoke-NodeExitCode -ArgumentList @('--experimental-strip-types', $scriptPath, $dbPath) `
        -WorkingDirectory $tempDir
    
    Remove-Item -LiteralPath $scriptPath -Force -ErrorAction SilentlyContinue
    
    if ($sqliteExit -ne 0) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='encrypted-sqlite'; status='FAIL'; reason='sqlite-script-failed';
            exitCode=$sqliteExit; tempDirListing=$listing; preservedTempDir=$tempDir
        }
        exit 1
    }
    
    Write-Status @{ stage='encrypted-sqlite'; status='OK' }
    $completedStages += 'encrypted-sqlite'

    # Test encrypted audio store using createFileAudioStore
    Write-Status @{ stage='audio-store'; status='running' }
    
    $audioDir = Join-Path $tempDir 'test-audio'
    
    $audioScript = @"
import { createFileAudioStore } from './adapters/audio-file/src/index.ts';

const audioDir = process.argv[2];

const fileKey = {
  bytes: new Uint8Array(32),
  version: 1
};
crypto.getRandomValues(fileKey.bytes);

const store = await createFileAudioStore(audioDir, fileKey);

const testAudio = new Uint8Array(1024);
crypto.getRandomValues(testAudio);

const id = 'audio/session_test/550e8400-e29b-41d4-a716-446655440000';
const metadata = {
  contentLength: 1024,
  contentType: 'audio/wav',
  expiresAt: new Date(Date.now() + 86400000).toISOString()
};

// Create a ReadableStream from the test audio
const stream = new ReadableStream({
  start(controller) {
    controller.enqueue(testAudio);
    controller.close();
  }
});

await store.put(id, stream, metadata);

const retrieved = await store.get(id);
if (!retrieved || !retrieved.body) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'get-failed' }));
    process.exit(1);
}

// Read the stream
const reader = retrieved.body.getReader();
const chunks = [];
while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    chunks.push(value);
}
const combined = new Uint8Array(chunks.reduce((acc, c) => acc + c.length, 0));
let offset = 0;
for (const chunk of chunks) {
    combined.set(chunk, offset);
    offset += chunk.length;
}

if (combined.length !== 1024) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'size-mismatch', got: combined.length }));
    process.exit(1);
}

console.log(JSON.stringify({ status: 'OK' }));
"@
    $scriptPath = Join-Path $tempDir '_audio-test.ts'
    Set-Content -LiteralPath $scriptPath -Value $audioScript -Encoding UTF8
    
    $audioExit = Invoke-NodeExitCode -ArgumentList @('--experimental-strip-types', $scriptPath, $audioDir) `
        -WorkingDirectory $tempDir
    
    Remove-Item -LiteralPath $scriptPath -Force -ErrorAction SilentlyContinue
    
    if ($audioExit -ne 0) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='audio-store'; status='FAIL'; reason='audio-script-failed';
            exitCode=$audioExit; tempDirListing=$listing; preservedTempDir=$tempDir
        }
        exit 1
    }
    
    Write-Status @{ stage='audio-store'; status='OK' }
    $completedStages += 'audio-store'

    # Test scheduler tick using createNodeScheduler
    Write-Status @{ stage='scheduler'; status='running' }
    
    $schedulerScript = @"
import { createNodeScheduler } from './adapters/scheduler-node/src/index.ts';

let ticked = false;

const runner = {
  async run(kind, nowIso) {
    ticked = true;
    return { kind, nowIso, completedAt: new Date().toISOString(), counters: {} };
  }
};

const scheduler = createNodeScheduler(runner, (failure) => {
  console.log(JSON.stringify({ status: 'FAIL', reason: 'scheduler-error', failure }));
  process.exit(1);
});

// Schedule to run every minute
await scheduler.schedule('audio_expiry', '* * * * *');

// Wait up to 65 seconds for a tick
const deadline = Date.now() + 65000;
while (!ticked && Date.now() < deadline) {
    await new Promise(resolve => setTimeout(resolve, 1000));
}

await scheduler.close();

if (!ticked) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'no-tick' }));
    process.exit(1);
}
console.log(JSON.stringify({ status: 'OK' }));
"@
    $scriptPath = Join-Path $tempDir '_scheduler-test.ts'
    Set-Content -LiteralPath $scriptPath -Value $schedulerScript -Encoding UTF8
    
    $schedulerExit = Invoke-NodeExitCode -ArgumentList @('--experimental-strip-types', $scriptPath) `
        -WorkingDirectory $tempDir
    
    Remove-Item -LiteralPath $scriptPath -Force -ErrorAction SilentlyContinue
    
    if ($schedulerExit -ne 0) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='scheduler'; status='FAIL'; reason='scheduler-script-failed';
            exitCode=$schedulerExit; tempDirListing=$listing; preservedTempDir=$tempDir
        }
        exit 1
    }
    
    Write-Status @{ stage='scheduler'; status='OK' }
    $completedStages += 'scheduler'

    # Test identity creation using createLocalSingleIdentity
    Write-Status @{ stage='identity'; status='running' }
    
    $identityScript = @"
import { createLocalSingleIdentity } from './apps/local-service/src/identity.ts';

const identity = createLocalSingleIdentity({
  interactiveUsername: 'test-user',
  orgId: 'test-org-001'
});

const userId = identity.stableUserId;
if (!userId || typeof userId !== 'string' || userId.length < 10) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'invalid-user-id' }));
    process.exit(1);
}

const bearer = identity.bearer;
if (!bearer || typeof bearer !== 'string' || !bearer.startsWith('CCC-LOCAL-SINGLEv1-')) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'invalid-bearer' }));
    process.exit(1);
}

// Test resolve with a mock request
const mockRequest = new Request('http://localhost/test', {
    headers: { 'Authorization': 'Bearer ' + bearer }
});
const actor = await identity.resolve(mockRequest);
if (!actor || actor.userId !== userId) {
    console.log(JSON.stringify({ status: 'FAIL', reason: 'actor-mismatch' }));
    process.exit(1);
}

identity.close();
console.log(JSON.stringify({ status: 'OK', userIdLength: userId.length }));
"@
    $scriptPath = Join-Path $tempDir '_identity-test.ts'
    Set-Content -LiteralPath $scriptPath -Value $identityScript -Encoding UTF8
    
    $identityExit = Invoke-NodeExitCode -ArgumentList @('--experimental-strip-types', $scriptPath) `
        -WorkingDirectory $tempDir
    
    Remove-Item -LiteralPath $scriptPath -Force -ErrorAction SilentlyContinue
    
    if ($identityExit -ne 0) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='identity'; status='FAIL'; reason='identity-script-failed';
            exitCode=$identityExit; tempDirListing=$listing; preservedTempDir=$tempDir
        }
        exit 1
    }
    
    Write-Status @{ stage='identity'; status='OK' }
    $completedStages += 'identity'

    # Test endpoint record file
    Write-Status @{ stage='endpoint-record'; status='running' }
    
    $endpointPath = Join-Path $tempDir 'endpoint.json'
    $endpointData = @{
        host = '127.0.0.1'
        port = 0
        mode = 'local-single'
        created = (Get-Date).ToUniversalTime().ToString('o')
    }
    $endpointData | ConvertTo-Json | Set-Content -LiteralPath $endpointPath -Encoding UTF8
    
    if (-not (Test-Path -LiteralPath $endpointPath)) {
        $listing = Get-DirListing $tempDir
        Write-Status @{ 
            stage='endpoint-record'; status='FAIL'; reason='file-not-created';
            tempDirListing=$listing; preservedTempDir=$tempDir
        }
        exit 1
    }
    
    $content = Get-Content -LiteralPath $endpointPath -Raw | ConvertFrom-Json
    if ($content.host -ne '127.0.0.1' -or $content.mode -ne 'local-single') {
        Write-Status @{ stage='endpoint-record'; status='FAIL'; reason='content-mismatch'; preservedTempDir=$tempDir }
        exit 1
    }
    
    Write-Status @{ stage='endpoint-record'; status='OK' }
    $completedStages += 'endpoint-record'

    # All passed - cleanup
    Write-Status @{ stage='cleanup'; status='running' }
    
    if (Test-Path -LiteralPath $tempDir) {
        Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
    
    Write-Status @{ stage='cleanup'; status='OK'; completedStages=$completedStages; allPassed=$true }
    exit 0

} catch {
    $listing = if ($tempDir) { Get-DirListing $tempDir } else { '(no tempDir)' }
    Write-Status @{ 
        stage='error'; status='FAIL'; reason=$_.Exception.Message;
        completedStages=$completedStages; tempDirListing=$listing; preservedTempDir=$tempDir
    }
    exit 1
}
